import streamlit as st
import sys
import os
import re
from datetime import datetime
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
from typing import List, Dict, Any
import time

# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

# Import our modules
from rag.rag_system import RAGSystem
from rag.vector_db import VectorDatabase
from config import Config

# Add comprehensive scraper import
try:
    from scrapers.comprehensive_scraper import ComprehensiveScraper
    SCRAPER_AVAILABLE = True
except ImportError:
    SCRAPER_AVAILABLE = False

# Page configuration
st.set_page_config(
    page_title="IRDAI RAG Chatbot",
    page_icon="🏛️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for professional styling
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #1e3c72 0%, #2a5298 100%);
        padding: 2rem;
        border-radius: 10px;
        margin-bottom: 2rem;
        text-align: center;
        color: white;
    }
    
    .stats-card {
        background: white;
        padding: 1.5rem;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        border-left: 4px solid #2a5298;
        margin-bottom: 1rem;
    }
    
    .confidence-high {
        color: #28a745;
        font-weight: bold;
    }
    
    .confidence-medium {
        color: #ffc107;
        font-weight: bold;
    }
    
    .confidence-low {
        color: #dc3545;
        font-weight: bold;
    }
    
    .stButton > button {
        background-color: #2a5298;
        color: white;
        border: none;
        border-radius: 5px;
        padding: 0.5rem 1rem;
        font-weight: bold;
    }
    
    .stButton > button:hover {
        background-color: #1e3c72;
    }
    
    .status-success {
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        color: #155724;
    }
    
    .status-warning {
        background-color: #fff3cd;
        border: 1px solid #ffeaa7;
        color: #856404;
    }
    
    .status-error {
        background-color: #f8d7da;
        border: 1px solid #f5c6cb;
        color: #721c24;
    }
</style>
""", unsafe_allow_html=True)

# SIMPLIFIED SYSTEM SETUP USING EXISTING FUNCTIONS
def integrated_system_setup():
    """Simplified system setup using existing scraping functions"""
    
    setup_progress = st.progress(0)
    status_container = st.container()
    
    with status_container:
        st.markdown("### 🔧 **System Initialization**")
        
        # Step 1: Check if system needs setup
        setup_progress.progress(10)
        setup_status = st.empty()
        setup_status.info("🔍 Checking system status...")
        
        try:
            vector_db = VectorDatabase()
            stats = vector_db.get_collection_stats()
            total_docs = stats.get('total_documents', 0)
            
            if total_docs > 0:
                setup_status.success(f"✅ System ready! Found {total_docs} documents in database.")
                setup_progress.progress(100)
                return True, "System already initialized"
            else:
                setup_status.warning("⚠️ Database empty. Running comprehensive setup...")
        except Exception as e:
            setup_status.warning(f"⚠️ Database error: {e}. Running fresh setup...")
        
        # Step 2: Use comprehensive scraper
        setup_progress.progress(40)
        setup_status.info("🌐 Using comprehensive scraper to collect documents...")
        
        try:
            # Import and run the fix_all_websites_system function
            from fix_all_websites_system import integrate_comprehensive_documents
            
            setup_status.info("🔄 Running comprehensive document integration...")
            success = integrate_comprehensive_documents()
            
            if success:
                setup_progress.progress(100)
                setup_status.success("🎉 **SYSTEM SETUP COMPLETE!** Ready for queries.")
                return True, "Setup completed successfully"
            else:
                setup_status.error("❌ Comprehensive integration failed")
                return False, "Integration failed"
                
        except Exception as e:
            setup_status.error(f"❌ Setup failed: {e}")
            return False, f"Setup error: {e}"

# Cache the initialization
@st.cache_resource
def initialize_complete_system():
    """Initialize the complete system with caching"""
    try:
        # Check if already initialized
        vector_db = VectorDatabase()
        stats = vector_db.get_collection_stats()
        if stats.get('total_documents', 0) > 0:
            return RAGSystem(), True, "System already ready"
        
        # Need to initialize
        return None, False, "Needs setup"
    except:
        return None, False, "Needs setup"

@st.cache_resource  
def initialize_comprehensive_scraper():
    """Initialize comprehensive scraper with caching"""
    if SCRAPER_AVAILABLE:
        try:
            return ComprehensiveScraper(use_selenium=False)
        except Exception as e:
            st.warning(f"Could not initialize scraper: {e}")
            return None
    return None

def format_confidence_score(score: float) -> str:
    """Format confidence score with color coding"""
    if score >= 0.8:
        return f'<span class="confidence-high">{score:.2f}</span>'
    elif score >= 0.6:
        return f'<span class="confidence-medium">{score:.2f}</span>'
    else:
        return f'<span class="confidence-low">{score:.2f}'

def create_confidence_gauge(score: float):
    """Create a confidence gauge chart"""
    fig = go.Figure(go.Indicator(
        mode = "gauge+number",
        value = score,
        domain = {'x': [0, 1], 'y': [0, 1]},
        title = {'text': "Confidence Score"},
        gauge = {
            'axis': {'range': [None, 1]},
            'bar': {'color': "darkblue"},
            'steps': [
                {'range': [0, 0.6], 'color': "lightgray"},
                {'range': [0.6, 0.8], 'color': "yellow"},
                {'range': [0.8, 1], 'color': "green"}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': 0.9
            }
        }
    ))
    
    fig.update_layout(height=300)
    return fig

@st.cache_data
def get_system_stats():
    """Get system statistics with caching"""
    try:
        vector_db = VectorDatabase()
        return vector_db.get_collection_stats()
    except Exception as e:
        st.error(f"Failed to get system stats: {e}")
        return {}

def display_sources(sources: List[Dict[str, Any]]):
    """Display sources in a formatted way"""
    for i, source in enumerate(sources, 1):
        with st.expander(f"📚 Source {i}: {source['title'][:50]}..." if len(source['title']) > 50 else f"📚 Source {i}: {source['title']}", expanded=True):
            
            col1, col2 = st.columns([3, 1])
            
            with col1:
                st.markdown(f"**🌐 Source Website:** {source['url']}")
                st.markdown(f"**📂 Document Type:** {source['source_type'].replace('_', ' ').title()}")
                st.markdown(f"**📄 Relevance Score:** {source['relevance_score']:.3f}")
                
                # Show content preview
                st.markdown(f"**📝 Content Preview:**")
                st.markdown(f"_{source['snippet']}_")
                
            with col2:
                # Create mini gauge for relevance with unique key
                mini_fig = go.Figure(go.Indicator(
                    mode = "gauge+number",
                    value = source['relevance_score'],
                    domain = {'x': [0, 1], 'y': [0, 1]},
                    gauge = {
                        'axis': {'range': [None, 1]},
                        'bar': {'color': "lightblue"},
                        'bgcolor': "white",
                        'borderwidth': 2,
                        'bordercolor': "gray"
                    }
                ))
                mini_fig.update_layout(height=150, margin=dict(l=20, r=20, t=20, b=20))
                # FIX: Add unique key to prevent duplicate element ID error
                st.plotly_chart(mini_fig, use_container_width=True, key=f"relevance_gauge_{i}_{hash(source['url']) % 10000}")
            
            # Display reference document links prominently
            if source.get('document_links') and len(source['document_links']) > 0:
                st.markdown("---")
                st.markdown("### 🔗 **Reference Document Links**")
                st.markdown("*Official documents, regulations, and policy files:*")
                
                # Categorize documents by type
                document_detail_links = []
                direct_pdf_links = []
                direct_doc_links = []
                other_links = []
                
                for doc_link in source['document_links']:
                    if 'document-detail' in doc_link.lower():
                        document_detail_links.append(doc_link)
                    elif doc_link.lower().endswith('.pdf'):
                        direct_pdf_links.append(doc_link)
                    elif doc_link.lower().endswith(('.doc', '.docx')):
                        direct_doc_links.append(doc_link)
                    else:
                        other_links.append(doc_link)
                
                # Display document detail pages (IRDAI specific)
                if document_detail_links:
                    st.markdown("**📋 IRDAI Document Detail Pages:**")
                    for doc_link in document_detail_links[:5]:
                        # Extract document ID if available
                        doc_id_match = re.search(r'documentId=(\d+)', doc_link)
                        if doc_id_match:
                            doc_id = doc_id_match.group(1)
                            st.markdown(f"- [📋 IRDAI Document ID: {doc_id}]({doc_link})")
                        else:
                            st.markdown(f"- [📋 IRDAI Document Detail]({doc_link})")
                    
                    if len(document_detail_links) > 5:
                        st.markdown(f"... and {len(document_detail_links) - 5} more document detail pages")
                
                # Display direct PDF links
                if direct_pdf_links:
                    st.markdown("**📄 Direct PDF Downloads:**")
                    for doc_link in direct_pdf_links[:5]:
                        doc_name = doc_link.split('/')[-1].replace('%20', ' ')
                        if len(doc_name) > 50:
                            doc_name = doc_name[:47] + "..."
                        st.markdown(f"- [📄 {doc_name}]({doc_link})")
                    
                    if len(direct_pdf_links) > 5:
                        st.markdown(f"... and {len(direct_pdf_links) - 5} more PDF documents")
                
                # Display Word documents
                if direct_doc_links:
                    st.markdown("**📝 Word Documents:**")
                    for doc_link in direct_doc_links[:3]:
                        doc_name = doc_link.split('/')[-1].replace('%20', ' ')
                        if len(doc_name) > 50:
                            doc_name = doc_name[:47] + "..."
                        st.markdown(f"- [📝 {doc_name}]({doc_link})")
                    
                    if len(direct_doc_links) > 3:
                        st.markdown(f"... and {len(direct_doc_links) - 3} more Word documents")
                
                # Display other document links
                if other_links:
                    st.markdown("**🔗 Other Document Links:**")
                    for doc_link in other_links[:3]:
                        if 'documentId=' in doc_link:
                            doc_id_match = re.search(r'documentId=(\d+)', doc_link)
                            if doc_id_match:
                                doc_id = doc_id_match.group(1)
                                st.markdown(f"- [🔗 Document ID: {doc_id}]({doc_link})")
                            else:
                                st.markdown(f"- [🔗 Document Link]({doc_link})")
                        else:
                            doc_name = doc_link.split('/')[-1] if '/' in doc_link else "Document"
                            st.markdown(f"- [🔗 {doc_name}]({doc_link})")
                
                # Show summary statistics
                total_docs = len(source['document_links'])
                st.markdown("---")
                st.markdown(f"**📊 Document Summary:**")
                st.markdown(f"- **Total Documents:** {total_docs}")
                st.markdown(f"- **IRDAI Document Pages:** {len(document_detail_links)}")
                st.markdown(f"- **Direct PDF Downloads:** {len(direct_pdf_links)}")
                st.markdown(f"- **Word Documents:** {len(direct_doc_links)}")
                st.markdown(f"- **Other Links:** {len(other_links)}")
                
            else:
                st.markdown("---")
                st.markdown("### 🔗 **Reference Document Links**")
                st.markdown("*No specific document links found for this source.*")
                st.markdown("*Information is from the main webpage content.*")

def perform_dynamic_search(query: str, rag_system, scraper):
    """Enhanced dynamic search with proper query isolation and cache bypass"""
    motor_vehicle_keywords = ["motor vehicle", "third party", "base premium", "liability rules"]
    irdai_keywords = ["irdai", "insurance regulatory", "regulatory authority", "insurance rules", "insurance regulations"]
    
    # CRITICAL: Clear previous query state to prevent contamination
    if scraper:
        scraper.clear_query_state()  # Clear visited URLs and document cache
        scraper.current_query = query  # Set new query
    
    # Get user's search mode preference
    search_mode = st.session_state.get('search_mode', 'Smart Search (Recommended)')
    force_fresh_search = st.session_state.get('force_fresh_search', False)
    
    # Check if this is specifically an IRDAI query
    is_irdai_query = any(keyword in query.lower() for keyword in irdai_keywords)
    should_force_dynamic = any(keyword in query.lower() for keyword in motor_vehicle_keywords)
    
    try:
        # CRITICAL: Check if user wants to force fresh search
        if force_fresh_search:
            should_scrape = True
            scrape_reason = "🔄 Force Fresh Search requested - Bypassing cache and performing real-time search"
            st.session_state.force_fresh_search = False  # Reset flag
        else:
            response = rag_system.query(query)
            query_relevance_check = any(word in response.answer.lower() for word in query.lower().split() if len(word) > 3)
            
            # ENHANCED: More strict confidence evaluation for exact document matching
            # Check if the response actually contains the correct document ID or year
            response_contains_query_year = False
            query_years = re.findall(r'\b(20\d{2})\b', query)
            if query_years:
                for year in query_years:
                    if year in response.answer:
                        response_contains_query_year = True
                        break
            
            # Check if response has exact title match in sources
            exact_title_match_in_sources = False
            if response.sources:
                for source in response.sources:
                    source_title = source.get('title', '').lower()
                    if query.lower().strip() in source_title or source_title in query.lower().strip():
                        exact_title_match_in_sources = True
                        break
            
            # Enhanced logic for when to perform real-time scraping
            should_scrape = False
            scrape_reason = ""
            
            if search_mode == "IRDAI Only":
                should_scrape = True
                scrape_reason = "IRDAI Only mode - always performing real-time search"
            elif search_mode == "All Sources":
                should_scrape = True
                scrape_reason = "All Sources mode - performing comprehensive real-time search"
            elif should_force_dynamic:
                should_scrape = True
                scrape_reason = "Motor Vehicle Insurance Query Detected - Performing specialized real-time search"
            elif response.confidence_score < 0.8:
                should_scrape = True
                scrape_reason = "Low confidence from static database - Performing real-time search"
            elif not query_relevance_check:
                should_scrape = True
                scrape_reason = "Query not well-matched in static database - Performing real-time search"
            elif query_years and not response_contains_query_year:
                should_scrape = True
                scrape_reason = f"Query contains specific year ({', '.join(query_years)}) but response doesn't match - Performing real-time search"
            elif not exact_title_match_in_sources and "obligatory cession" in query.lower():
                should_scrape = True
                scrape_reason = "Specific document query but no exact title match found - Performing real-time search"
            elif "2024-25" in query and "2024-25" not in response.answer:
                should_scrape = True
                scrape_reason = "Query asks for 2024-25 but response doesn't contain this year - Performing real-time search"
        
        if should_scrape:
            st.info(f"🔍 **{scrape_reason}**")
            
            if scraper:
                with st.spinner("🌐 Searching for latest information..."):
                    # CRITICAL: Disable demo mode and clear state
                    scraper.demo_mode = False
                    scraper.clear_query_state()  # Ensure clean state
                    
                    scraped_documents = None
                    
                    # Determine scraping strategy based on search mode and query
                    if search_mode == "IRDAI Only" or is_irdai_query:
                        st.info(f"🎯 **Searching IRDAI website for: '{query}'**")
                        scraped_documents = scraper.scrape_irdai_comprehensive(query)
                    elif search_mode == "All Sources":
                        st.info(f"🌐 **Searching all insurance websites for: '{query}'**")
                        scraped_documents = scraper.scrape_all_websites_comprehensive(query)
                    else:
                        # Smart search - choose based on query content
                        if is_irdai_query or any(word in query.lower() for word in ["regulation", "circular", "notification", "guideline"]):
                            st.info(f"🎯 **Smart Search targeting IRDAI for: '{query}'**")
                            scraped_documents = scraper.scrape_irdai_comprehensive(query)
                        else:
                            st.info(f"🌐 **Smart Search comprehensive for: '{query}'**")
                            scraped_documents = scraper.scrape_all_websites_comprehensive(query)
                    
                    if scraped_documents:
                        st.success(f"🎯 Found {len(scraped_documents)} relevant documents from real-time search!")
                        
                        # Show what we found
                        for i, doc in enumerate(scraped_documents[:3]):
                            doc_id = doc.metadata.get('document_id', 'N/A')
                            exact_match = doc.metadata.get('exact_match', False)
                            match_type = "✅ EXACT MATCH" if exact_match else "⚠️ Partial Match"
                            st.info(f"{match_type}: {doc.title} (ID: {doc_id})")
                        
                        from utils.document_processor import DocumentProcessor
                        processor = DocumentProcessor()
                        
                        class ScrapedContent:
                            def __init__(self, doc):
                                self.url = doc.url
                                self.title = doc.title
                                self.content = doc.content
                                self.source_type = doc.source_type
                                self.document_links = doc.document_links
                                self.metadata = doc.metadata
                        
                        scraped_content = [ScrapedContent(doc) for doc in scraped_documents]
                        all_chunks = []
                        
                        # Generate unique IDs with query fingerprint to prevent collision
                        import hashlib
                        query_hash = hashlib.md5(query.encode()).hexdigest()[:8]
                        processed_ids = set()
                        
                        for content in scraped_content:
                            try:
                                chunks = processor.process_scraped_content([content])
                                enriched_chunks = processor.enrich_metadata(chunks)
                                
                                # Filter out duplicate IDs and add query-specific IDs
                                unique_chunks = []
                                for chunk in enriched_chunks:
                                    chunk_id = getattr(chunk, 'id', None) or getattr(chunk, 'chunk_id', None)
                                    if chunk_id and chunk_id not in processed_ids:
                                        processed_ids.add(chunk_id)
                                        unique_chunks.append(chunk)
                                    elif not chunk_id:
                                        # Generate query-specific unique ID
                                        import uuid
                                        new_id = f"q_{query_hash}_{uuid.uuid4().hex[:8]}"
                                        if hasattr(chunk, 'id'):
                                            chunk.id = new_id
                                        elif hasattr(chunk, 'chunk_id'):
                                            chunk.chunk_id = new_id
                                        unique_chunks.append(chunk)
                                
                                all_chunks.extend(unique_chunks)
                                
                            except Exception as e:
                                st.warning(f"Error processing {content.title[:30]}...")
                                continue
                        
                        if all_chunks:
                            try:
                                # Create a fresh vector database instance with query isolation
                                vector_db = VectorDatabase()
                                
                                # Additional safety check - ensure all chunks have query-specific unique IDs
                                final_chunks = []
                                used_ids = set()
                                
                                for i, chunk in enumerate(all_chunks):
                                    chunk_id = getattr(chunk, 'id', None) or getattr(chunk, 'chunk_id', None)
                                    if not chunk_id or chunk_id in used_ids:
                                        # Generate truly unique ID with query fingerprint
                                        import uuid
                                        import time
                                        new_id = f"rt_q_{query_hash}_{uuid.uuid4().hex[:8]}_{int(time.time())}_{i}"
                                        if hasattr(chunk, 'id'):
                                            chunk.id = new_id
                                        elif hasattr(chunk, 'chunk_id'):
                                            chunk.chunk_id = new_id
                                        chunk_id = new_id
                                    
                                    used_ids.add(chunk_id)
                                    final_chunks.append(chunk)
                                
                                # Limit the number of chunks to avoid overwhelming the system
                                if len(final_chunks) > 100:
                                    st.info(f"📊 Limiting to top 100 most relevant chunks (from {len(final_chunks)} found)")
                                    final_chunks = final_chunks[:100]
                                
                                # Add documents with better error handling
                                try:
                                    vector_db.add_documents(final_chunks)
                                    st.success(f"✅ Successfully added {len(final_chunks)} new document chunks to search index")
                                except Exception as add_error:
                                    st.warning(f"⚠️ Error adding some documents: {add_error}")
                                    # Try to add documents one by one to identify problematic ones
                                    successfully_added = 0
                                    for chunk in final_chunks:
                                        try:
                                            vector_db.add_documents([chunk])
                                            successfully_added += 1
                                        except:
                                            continue
                                    if successfully_added > 0:
                                        st.info(f"📊 Successfully added {successfully_added} documents")
                                
                                # Query with fresh data
                                updated_response = rag_system.query(query)
                                return updated_response, "dynamic_scraping"
                                
                            except Exception as e:
                                st.error(f"Error adding documents to vector database: {e}")
                                st.info("💡 Using original response from static database")
                                return response, "static_db_fallback"
                        else:
                            st.warning("No processable content found in scraped documents")
                    else:
                        st.warning("No relevant documents found in real-time search")
                        # Return empty response if no exact matches found
                        class EmptyResponse:
                            def __init__(self):
                                self.answer = f"No exact matches found for '{query}' in the IRDAI website. The document may not exist or may have a different title. Please try rephrasing your query or check the IRDAI website directly."
                                self.confidence_score = 0.0
                                self.sources = []
                        return EmptyResponse(), "no_matches_found"
            else:
                st.warning("Real-time scraper not available")
        else:
            if not force_fresh_search:
                st.info("📚 **Using existing database** - Found relevant information in static collection")
                return response, "static_db"
        
        # Fallback to original response if we have one
        if 'response' in locals():
            return response, "static_db"
        else:
            class FallbackResponse:
                def __init__(self):
                    self.answer = f"I apologize, but I couldn't find information about '{query}'. Please try rephrasing your question or use the 'Force Fresh Search' button."
                    self.confidence_score = 0.0
                    self.sources = []
            return FallbackResponse(), "error"
        
    except Exception as e:
        st.error(f"Error in dynamic search: {e}")
        
        class FallbackResponse:
            def __init__(self):
                self.answer = f"I apologize, but I encountered an error while searching for information about '{query}'. Please try rephrasing your question or check the IRDAI website directly at https://irdai.gov.in"
                self.confidence_score = 0.0
                self.sources = []
        
        return FallbackResponse(), "error"

def create_analytics_dashboard():
    """Create analytics dashboard"""
    st.header("📊 System Analytics")
    
    # Get system stats
    stats = get_system_stats()
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            label="Total Documents",
            value=stats.get('total_documents', 0),
            delta=None
        )
    
    with col2:
        st.metric(
            label="Collection Name",
            value=stats.get('collection_name', 'N/A'),
            delta=None
        )
    
    with col3:
        st.metric(
            label="Embedding Model",
            value="MiniLM-L6-v2",
            delta=None
        )
    
    with col4:
        st.metric(
            label="Vector DB",
            value="ChromaDB",
            delta=None
        )
    
    # Source type distribution
    if 'source_distribution' in st.session_state:
        st.subheader("📈 Source Type Distribution")
        
        source_data = pd.DataFrame([
            {'Type': 'Regulatory', 'Count': 1},
            {'Type': 'Life Insurance', 'Count': 3},
            {'Type': 'General Insurance', 'Count': 5}
        ])
        
        fig = px.pie(source_data, values='Count', names='Type', 
                     title="Document Sources by Type",
                     color_discrete_sequence=['#FF6B6B', '#4ECDC4', '#45B7D1'])
        st.plotly_chart(fig, use_container_width=True)

def main():
    # Header
    st.markdown("""
    <div class="main-header">
        <h1>🏛️ IRDAI RAG Chatbot</h1>
        <p>Intelligent Insurance Regulatory Assistant</p>
        <p><em>Smart Search with Targeted Real-time Updates</em></p>
    </div>
    """, unsafe_allow_html=True)
    
    # Initialize session state
    if 'messages' not in st.session_state:
        st.session_state.messages = []
    if 'system_ready' not in st.session_state:
        st.session_state.system_ready = False
    if 'setup_attempted' not in st.session_state:
        st.session_state.setup_attempted = False

    # Add Quick Start option in sidebar
    with st.sidebar:
        if st.button("🚀 **Quick Start (Skip Setup)**"):
            st.session_state.system_ready = True
            st.session_state.setup_attempted = True
            st.success("Quick start enabled! You can now try basic functionality.")
            st.rerun()

    # System Initialization Section
    if not st.session_state.system_ready and not st.session_state.setup_attempted:
        st.markdown("## 🚀 **System Initialization**")
        st.info("💡 **First-time setup**: The system will use the comprehensive scraper to build a complete knowledge base.")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("🔧 **Initialize Complete System**", type="primary"):
                st.session_state.setup_attempted = True
                with st.container():
                    success, message = integrated_system_setup()
                    if success:
                        st.session_state.system_ready = True
                        st.success("🎉 **System Ready!** You can now ask questions.")
                        time.sleep(2)
                        st.rerun()
                    else:
                        st.error(f"❌ Setup failed: {message}")
                        st.info("💡 You can try the initialization again or use Quick Start for testing.")
        
        with col2:
            if st.button("⚡ **Quick Start Demo**", type="secondary"):
                st.session_state.system_ready = True
                st.session_state.setup_attempted = True
                st.info("🚀 Quick start mode enabled! Limited functionality available.")
                time.sleep(1)
                st.rerun()
        
        st.markdown("---")
        st.markdown("### 📋 **What the complete initialization will do:**")
        st.markdown("1. 🎯 Use targeted scraping based on query type")
        st.markdown("2. 📄 Process and index documents efficiently")  
        st.markdown("3. 🧪 Validate system functionality")
        st.markdown("4. ✅ Prepare for your questions!")
        return

    # Initialize systems
    if st.session_state.system_ready and 'rag_system' not in st.session_state:
        try:
            with st.spinner("🔄 Initializing systems..."):
                st.session_state.rag_system, ready, status = initialize_complete_system()
                if not ready:
                    st.warning("⚠️ Using simplified mode. Some features may be limited.")
                    st.session_state.rag_system = None
        except Exception as e:
            st.error(f"Initialization error: {e}")
            st.info("💡 Try refreshing the page or use the 'Reinitialize System' button.")

    # Initialize scraper
    if 'scraper' not in st.session_state:
        st.session_state.scraper = initialize_comprehensive_scraper()

    # Sidebar
    with st.sidebar:
        st.header("🎯 System Overview")
        
        if st.session_state.system_ready:
            try:
                vector_db = VectorDatabase()
                stats = vector_db.get_collection_stats()
                st.markdown(f"""
                <div class="stats-card status-success">
                    <h4>📊 System Status: ✅ READY</h4>
                    <p><strong>Documents:</strong> {stats.get('total_documents', 0)}</p>
                    <p><strong>Collection:</strong> {stats.get('collection_name', 'N/A')}</p>
                    <p><strong>Scraper:</strong> {'✅ Available' if st.session_state.scraper else '❌ Not Available'}</p>
                </div>
                """, unsafe_allow_html=True)
            except:
                st.markdown("""
                <div class="stats-card status-warning">
                    <h4>📊 System Status: ⚠️ LIMITED</h4>
                    <p>Some features may not work</p>
                </div>
                """, unsafe_allow_html=True)
        else:
            st.markdown("""
            <div class="stats-card status-error">
                <h4>📊 System Status: ❌ NOT READY</h4>
                <p>Please initialize the system first</p>
            </div>
            """, unsafe_allow_html=True)
        
        st.markdown("💡 **Sample Queries:**")
        sample_queries = [
            "Motor Vehicles Third Party Insurance Rules 2022",
            "IRDAI regulations for insurance companies", 
            "Insurance Amendment Act 2021 provisions",
            "IRDAI corporate governance guidelines 2024", 
            "LIC annual report financial highlights",
            "HDFC Life solvency ratio 2024",
            "New India surveyor empanelment criteria"
        ]
        
        for query in sample_queries:
            if st.button(f"📝 {query}", key=f"sample_{query[:20]}"):
                st.session_state.messages.append({"role": "user", "content": query})
                st.rerun()
        
        st.markdown("---")
        
        # Add search mode selector
        st.markdown("### 🔧 **Search Mode**")
        search_mode = st.radio(
            "Choose search preference:",
            ["Smart Search (Recommended)", "IRDAI Only", "All Sources"],
            help="Smart Search automatically chooses the best sources based on your query"
        )
        
        if 'search_mode' not in st.session_state:
            st.session_state.search_mode = "Smart Search (Recommended)"
        
        if search_mode != st.session_state.search_mode:
            st.session_state.search_mode = search_mode
            st.success(f"Search mode set to: {search_mode}")
        
        st.markdown("---")
        
        if st.button("🔄 Reinitialize System"):
            st.session_state.system_ready = False
            st.session_state.setup_attempted = False
            if 'rag_system' in st.session_state:
                del st.session_state.rag_system
            st.success("System reset! Please reinitialize.")
            st.rerun()
        
        if st.button("🗑️ Clear Chat"):
            st.session_state.messages = []
            st.rerun()

    # Main chat interface
    if st.session_state.system_ready:
        st.header("💬 Ask Your Questions")
        
        # Show current search mode with enhanced info
        current_mode = st.session_state.get('search_mode', 'Smart Search (Recommended)')
        if current_mode == "IRDAI Only":
            st.info("🎯 **Search Mode: IRDAI Only** - Every query will perform real-time search on IRDAI website for latest information")
        elif current_mode == "All Sources":
            st.info("🌐 **Search Mode: All Sources** - Every query will perform comprehensive real-time search across all insurance websites")
        else:
            st.info("🧠 **Search Mode: Smart Search** - Automatically chooses between static database and real-time search based on query confidence")
        
        # Add cache control buttons
        col1, col2, col3 = st.columns([2, 1, 1])
        
        with col2:
            if st.button("🔄 **Force Fresh Search**", help="Bypass cache and perform real-time search for next query"):
                st.session_state.force_fresh_search = True
                st.success("Next query will use fresh search!")
        
        with col3:
            if st.button("🗑️ **Clear Cache**", help="Clear vector database cache"):
                try:
                    vector_db = VectorDatabase()
                    vector_db.reset_database()
                    st.success("Cache cleared! Next query will rebuild from scratch.")
                    # Clear Streamlit cache
                    st.cache_data.clear()
                    st.cache_resource.clear()
                except Exception as e:
                    st.error(f"Error clearing cache: {e}")
        
        # Add search behavior explanation
        with st.expander("ℹ️ **How Search Works & Cache Control**", expanded=False):
            st.markdown("""
            **Search Modes:**
            - **🧠 Smart Search**: Uses static database first, performs real-time search if confidence is low or for specific queries
            - **🎯 IRDAI Only**: Always performs real-time search on IRDAI website for every query
            - **🌐 All Sources**: Always performs comprehensive real-time search across all websites for every query
            
            **When Real-time Search Happens:**
            - Motor vehicle insurance queries (always)
            - Low confidence from static database (< 0.8)
            - Query not well-matched in existing data
            - Specific year mentioned but not found in response
            - When "IRDAI Only" or "All Sources" mode is selected
            - When "Force Fresh Search" button is used
            
            **Cache Control:**
            - **🔄 Force Fresh Search**: Makes the next query bypass cache and search live websites
            - **🗑️ Clear Cache**: Completely clears the database cache - use if getting wrong results
            
            **Troubleshooting:**
            - If you get wrong document IDs or outdated information, use "Force Fresh Search"
            - If results seem completely off, use "Clear Cache" to start fresh
            """)
        
        # Display chat messages
        for message in st.session_state.messages:
            with st.chat_message(message["role"]):
                st.markdown(message["content"])
        
        # Chat input
        if prompt := st.chat_input("Ask about IRDAI regulations, insurance policies, or company information..."):
            st.session_state.messages.append({"role": "user", "content": prompt})
            
            with st.chat_message("user"):
                st.markdown(prompt)
            
            with st.chat_message("assistant"):
                if st.session_state.rag_system:
                    response, search_type = perform_dynamic_search(
                        prompt, 
                        st.session_state.rag_system, 
                        st.session_state.scraper
                    )
                    
                    # Enhanced search type messaging
                    if search_type == "dynamic_scraping":
                        st.success("🌐 **Real-time Search Results** - Fresh information from live website scraping")
                    elif search_type == "static_db":
                        st.info("📚 **Database Search Results** - Information from existing document collection")
                    elif search_type == "static_db_fallback":
                        st.warning("⚠️ **Fallback Results** - Using static database due to processing error, but fresh data was found")
                    elif search_type == "no_matches_found":
                        st.warning("⚠️ **No Exact Matches** - Real-time search found no matching documents")
                    else:
                        st.warning("⚠️ **Error Results** - Please try rephrasing your query")
                    
                    st.markdown("### 🤖 **Answer**")
                    st.markdown(response.answer)
                    
                    # Add feedback buttons for wrong results
                    if search_type == "static_db" and response.confidence_score > 0.8:
                        st.markdown("---")
                        st.markdown("**Is this result correct?**")
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            if st.button("✅ Correct", key=f"correct_{len(st.session_state.messages)}"):
                                st.success("Thank you for the feedback!")
                        
                        with col2:
                            if st.button("❌ Wrong - Need Fresh Search", key=f"wrong_{len(st.session_state.messages)}"):
                                st.session_state.force_fresh_search = True
                                st.warning("Next query will use fresh search. Please ask your question again.")
                    
                    if response.sources:
                        st.markdown("### 🌐 **Source Websites**")
                        source_websites = list(set([source['url'] for source in response.sources]))
                        for website in source_websites:
                            st.markdown(f"- {website}")
                    
                    if response.sources:
                        all_doc_links = []
                        for source in response.sources:
                            if source.get('document_links'):
                                all_doc_links.extend(source['document_links'])
                        
                        if all_doc_links:
                            st.markdown("### 🔗 **Reference Document Links Summary**")
                            st.markdown(f"**Total Documents Found:** {len(all_doc_links)}")
                            
                            # Categorize all documents
                            document_detail_links = [doc for doc in all_doc_links if 'document-detail' in doc.lower()]
                            pdf_docs = [doc for doc in all_doc_links if doc.lower().endswith('.pdf')]
                            doc_docs = [doc for doc in all_doc_links if doc.lower().endswith(('.doc', '.docx'))]
                            
                            # Show key document categories
                            if document_detail_links:
                                st.markdown(f"**📋 IRDAI Document Detail Pages:** {len(document_detail_links)} found")
                                for doc in document_detail_links[:2]:
                                    doc_id_match = re.search(r'documentId=(\d+)', doc)
                                    if doc_id_match:
                                        doc_id = doc_id_match.group(1)
                                        st.markdown(f"- [📋 IRDAI Document ID: {doc_id}]({doc})")
                                    else:
                                        st.markdown(f"- [📋 IRDAI Document Detail]({doc})")
                            
                            if pdf_docs:
                                st.markdown(f"**📄 PDF Documents:** {len(pdf_docs)} found")
                                for doc in pdf_docs[:2]:
                                    doc_name = doc.split('/')[-1].replace('%20', ' ')
                                    if len(doc_name) > 40:
                                        doc_name = doc_name[:37] + "..."
                                    st.markdown(f"- [📄 {doc_name}]({doc})")
                            
                            if doc_docs:
                                st.markdown(f"**📝 Word Documents:** {len(doc_docs)} found")
                                for doc in doc_docs[:2]:
                                    doc_name = doc.split('/')[-1].replace('%20', ' ')
                                    if len(doc_name) > 40:
                                        doc_name = doc_name[:37] + "..."
                                    st.markdown(f"- [📝 {doc_name}]({doc})")
                            
                            if len(all_doc_links) > 6:
                                st.markdown(f"*... and {len(all_doc_links) - 6} more documents (see detailed sources below)*")
                            
                            # Add a note about document types
                            st.info("💡 **Document Types Explained:**\n"
                                   "- **📋 IRDAI Document Detail Pages**: Official IRDAI regulation/circular detail pages\n"
                                   "- **📄 PDF Documents**: Direct downloadable PDF files\n"
                                   "- **📝 Word Documents**: Direct downloadable DOC/DOCX files")
                        
                        else:
                            st.markdown("### 🔗 **Reference Document Links**")
                            st.markdown("*No specific document links found. Information sourced from main webpage content.*")
                    
                    # Display confidence score
                    st.markdown("### 📊 **Confidence Score**")
                    col1, col2 = st.columns([1, 2])
                    
                    with col1:
                        st.markdown(f"**Score:** {format_confidence_score(response.confidence_score)}", 
                                  unsafe_allow_html=True)
                    
                    with col2:
                        fig = create_confidence_gauge(response.confidence_score)
                        st.plotly_chart(fig, use_container_width=True)
                    
                    # Display detailed sources
                    if response.sources:
                        st.markdown("### 📚 **Detailed Sources**")
                        display_sources(response.sources)
                    
                    # Add to message history
                    assistant_response = f"""
**Answer:** {response.answer}

**Search Type:** {search_type.replace('_', ' ').title()}

**Confidence Score:** {response.confidence_score:.2f}

**Sources Found:** {len(response.sources)}
"""
                    st.session_state.messages.append({"role": "assistant", "content": assistant_response})
                else:
                    st.error("RAG system not initialized properly")

if __name__ == "__main__":
    main()