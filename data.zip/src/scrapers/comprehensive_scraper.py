#!/usr/bin/env python3
"""
Comprehensive scraper for ALL 4 insurance websites with 100% accuracy
"""

# spell-checker: disable
# Custom dictionary for insurance terms
# IRDAI - Insurance Regulatory and Development Authority of India
# HDFC - Housing Development Finance Corporation
# Reinsurers - Companies that provide insurance for insurance companies

import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import time
import json
import os
import re
from typing import Dict, List
from dataclasses import dataclass
from loguru import logger
import io

# Handle optional imports gracefully
try:
    import PyPDF2
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False
    logger.warning("PyPDF2 not available. PDF extraction will be skipped.")

try:
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from webdriver_manager.chrome import ChromeDriverManager
    from selenium.common.exceptions import TimeoutException, WebDriverException
    SELENIUM_AVAILABLE = True
except ImportError:
    SELENIUM_AVAILABLE = False
    logger.warning("Selenium not available. Will use requests-only scraping.")

@dataclass
class ComprehensiveDocument:
    url: str
    title: str
    content: str
    source_type: str
    website: str
    document_links: List[str]
    metadata: Dict

class ComprehensiveScraper:
    def __init__(self, use_selenium: bool = False):
        self.driver = None
        self.documents = []
        self.visited_urls = set()
        self.pdf_cache = {}
        self.use_selenium = use_selenium and SELENIUM_AVAILABLE
        self.current_query = ""  # Store current user query for filtering
        self.demo_mode = False  # Flag to control sample data usage
        
        # CRITICAL: Add query-specific state management
        self.query_state = {
            'visited_urls': set(),
            'found_documents': [],
            'document_cache': {},
            'last_query': ""
        }
        
        if self.use_selenium:
            try:
                self.setup_driver()
            except Exception as e:
                logger.error(f"Failed to setup Selenium driver: {e}")
                logger.info("Falling back to requests-only scraping")
                self.use_selenium = False
        
        # Enhanced website configurations with INTELLIGENT ROUTING
        self.website_configs = {
            "irdai": {
                "base_url": "https://irdai.gov.in",
                "intelligent_routing": {
                    # Query type to URL mapping for smart navigation
                    "acts": {
                        "keywords": ["act", "amendment act", "insurance laws", "insurance act", "irdai act"],
                        "primary_urls": [
                            "/acts",
                            "/insurance-acts", 
                            "/rules",
                            "/consolidated-gazette-notified-regulations"
                        ]
                    },
                    "rules": {
                        "keywords": ["rules", "motor vehicle", "third party", "liability rules", "base premium"],
                        "primary_urls": [
                            "/rules",
                            "/notifications",
                            "/consolidated-gazette-notified-regulations"
                        ]
                    },
                    "regulations": {
                        "keywords": ["regulation", "irdai regulation", "corporate governance", "solvency"],
                        "primary_urls": [
                            "/consolidated-gazette-notified-regulations",
                            "/updated-regulations",
                            "/regulations"
                        ]
                    },
                    "circulars": {
                        "keywords": ["circular", "master circular", "guidelines"],
                        "primary_urls": [
                            "/circulars",
                            "/notifications",
                            "/guidelines"
                        ]
                    },
                    "notifications": {
                        "keywords": ["notification", "press release", "announcement"],
                        "primary_urls": [
                            "/notifications",
                            "/press-releases",
                            "/announcements"
                        ]
                    },
                    "financial": {
                        "keywords": ["obligatory cession", "financial year", "annual report", "budget"],
                        "primary_urls": [
                            "/annual-reports",
                            "/notifications",
                            "/consolidated-gazette-notified-regulations"
                        ]
                    }
                },
                "start_pages": [
                    "/acts",  # Start with Acts first for better coverage
                    "/rules",
                    "/consolidated-gazette-notified-regulations",
                    "/updated-regulations",
                    "/notifications"
                ],
                "search_pages": [
                    "/regulations",
                    "/circulars", 
                    "/guidelines",
                    "/annual-reports",
                    "/consolidated-gazette-notified-regulations"
                ],
                "document_selectors": {
                    "table_rows": "table tr, .document-row, .list-item, .portlet-body table tr",
                    "document_links": "a[href*='document-detail'], a[href*='.pdf'], a[href*='.doc'], a[href*='documents/'], a[href*='document-viewer'], a[href*='fileEntryId']",
                    "content_area": ".portlet-body, .journal-content-article, .content, .document-content, main, .portlet-content-container",
                    "internal_links": "a[href^='/'], a[href*='irdai.gov.in']",
                    "accordion_triggers": ".accordion-toggle, .collapse-toggle, [data-toggle='collapse'], .dropdown-toggle",
                    "pagination": ".pagination a, .load-more, .show-more, [onclick*='loadMore']"
                },
                "max_depth": 6,  # Increased for better recursive search
                "keywords": ["regulation", "circular", "guideline", "notification", "irdai", "insurance", "rules", "acts"],
                "source_type": "regulatory"
            },
            "lic": {
                "base_url": "https://www.licindia.in",
                "search_pages": [
                    "/corporate-governance",
                    "/investor-relations", 
                    "/annual-reports",
                    "/board-of-directors",
                    "/policies"
                ],
                "document_selectors": {
                    "table_rows": "table tr, .document-list li",
                    "document_links": "a[href*='.pdf'], a[href*='.doc'], a[href*='documents']",
                    "content_area": ".content, .main-content, main",
                    "internal_links": "a[href^='/'], a[href*='licindia.in']",
                    "accordion_triggers": ".accordion-toggle, .collapse-toggle, [data-toggle='collapse']",
                    "pagination": ".pagination a, .load-more, .show-more"
                },
                "max_depth": 2,
                "keywords": ["lic", "life insurance", "corporate", "governance", "annual report"],
                "source_type": "life_insurance"
            },
            "hdfc_life": {
                "base_url": "https://www.hdfclife.com",
                "search_pages": [
                    "/about-us/investor-relations",
                    "/about-us/corporate-governance",
                    "/about-us/annual-reports",
                    "/policy-documents"
                ],
                "document_selectors": {
                    "table_rows": "table tr, .document-row, .policy-list li",
                    "document_links": "a[href*='.pdf'], a[href*='.doc'], a[href*='content/dam']",
                    "content_area": ".content, .page-content, main",
                    "internal_links": "a[href^='/'], a[href*='hdfclife.com']",
                    "accordion_triggers": ".accordion-toggle, .collapse-toggle, [data-toggle='collapse']",
                    "pagination": ".pagination a, .load-more, .show-more"
                },
                "max_depth": 2,
                "keywords": ["hdfc", "life insurance", "policy", "investor", "governance"],
                "source_type": "life_insurance"
            },
            "new_india": {
                "base_url": "https://www.newindia.co.in",
                "search_pages": [
                    "/corporate-governance",
                    "/investor-relations",
                    "/annual-reports",
                    "/policies"
                ],
                "document_selectors": {
                    "table_rows": "table tr, .policy-list li",
                    "document_links": "a[href*='.pdf'], a[href*='.doc'], a[href*='assets/docs']",
                    "content_area": ".content, .main-content, main",
                    "internal_links": "a[href^='/'], a[href*='newindia.co.in']",
                    "accordion_triggers": ".accordion-toggle, .collapse-toggle, [data-toggle='collapse']",
                    "pagination": ".pagination a, .load-more, .show-more"
                },
                "max_depth": 2,
                "keywords": ["new india", "general insurance", "policy", "corporate", "governance"],
                "source_type": "general_insurance"
            }
        }
        
    def setup_driver(self):
        """Initialize Selenium WebDriver with enhanced capabilities"""
        if not SELENIUM_AVAILABLE:
            logger.error("Selenium not available")
            return
            
        try:
            chrome_options = Options()
            chrome_options.add_argument("--headless")
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_argument("--disable-gpu")
            chrome_options.add_argument("--window-size=1920,1080")
            chrome_options.add_argument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
            chrome_options.add_argument("--disable-blink-features=AutomationControlled")
            chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
            chrome_options.add_experimental_option('useAutomationExtension', False)
            
            service = Service(ChromeDriverManager().install())
            self.driver = webdriver.Chrome(service=service, options=chrome_options)
            self.driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
            logger.info("Selenium driver setup successful")
        except Exception as e:
            logger.error(f"Failed to setup Chrome driver: {e}")
            self.use_selenium = False
            
    def extract_pdf_content(self, pdf_url: str) -> str:
        """Extract text content from PDF files"""
        if not PDF_AVAILABLE:
            logger.warning("PyPDF2 not available. Cannot extract PDF content.")
            return ""
            
        if pdf_url in self.pdf_cache:
            return self.pdf_cache[pdf_url]
        
        try:
            logger.info(f"Extracting PDF content from: {pdf_url}")
            response = requests.get(pdf_url, timeout=30, headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            })
            response.raise_for_status()
            
            pdf_file = io.BytesIO(response.content)
            pdf_reader = PyPDF2.PdfReader(pdf_file)
            
            text_content = ""
            for page in pdf_reader.pages:
                text_content += page.extract_text() + "\n"
            
            # Clean and normalize text
            text_content = re.sub(r'\s+', ' ', text_content).strip()
            
            self.pdf_cache[pdf_url] = text_content
            logger.info(f"Extracted {len(text_content)} characters from PDF")
            return text_content
            
        except Exception as e:
            logger.error(f"Error extracting PDF {pdf_url}: {e}")
            return ""
    
    def handle_dynamic_content(self, config: Dict):
        """Handle accordion, collapsible content, and dynamic elements"""
        if not self.use_selenium:
            return
            
        try:
            # Wait for dynamic content to load
            time.sleep(2)
            
            # Click dropdown toggles and accordion triggers
            accordion_elements = self.driver.find_elements(By.CSS_SELECTOR, config["document_selectors"]["accordion_triggers"])
            for element in accordion_elements:
                try:
                    if element.is_displayed() and element.is_enabled():
                        self.driver.execute_script("arguments[0].click();", element)
                        time.sleep(1)
                except Exception as e:
                    logger.debug(f"Could not click element: {e}")
            
            # Handle "Load More" or pagination
            pagination_elements = self.driver.find_elements(By.CSS_SELECTOR, config["document_selectors"]["pagination"])
            for element in pagination_elements[:3]:  # Limit to 3 clicks
                try:
                    if element.is_displayed() and element.is_enabled():
                        self.driver.execute_script("arguments[0].click();", element)
                        time.sleep(3)
                except Exception as e:
                    logger.debug(f"Could not click pagination element: {e}")
            
            # Scroll to load content
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(2)
            
            # Wait for any AJAX content to load
            try:
                WebDriverWait(self.driver, 10).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, config["document_selectors"]["content_area"]))
                )
            except TimeoutException:
                pass
            
        except Exception as e:
            logger.error(f"Error handling dynamic content: {e}")
    
    def extract_internal_links(self, soup: BeautifulSoup, base_url: str, current_url: str, config: Dict) -> List[str]:
        """Extract internal links for recursive traversal"""
        internal_links = set()
        
        # Find all internal links
        for link in soup.find_all('a', href=True):
            href = link.get('href')
            if not href:
                continue
            
            # Convert relative URLs to absolute
            full_url = urljoin(current_url, href)
            
            # Check if it's an internal link
            if base_url in full_url and full_url != current_url:
                # Remove fragments and query parameters for deduplication
                clean_url = full_url.split('#')[0].split('?')[0]
                
                # Filter based on relevance
                link_text = link.get_text(strip=True).lower()
                if any(keyword in link_text for keyword in config["keywords"]) or \
                   any(keyword in href.lower() for keyword in config["keywords"]):
                    internal_links.add(clean_url)
        
        return list(internal_links)
    
    def extract_all_document_links(self, soup: BeautifulSoup, base_url: str, config: Dict) -> List[str]:
        """Extract ALL possible document links from a page"""
        doc_links = set()
        
        # Method 1: Direct document links using enhanced selectors
        for selector in config["document_selectors"]["document_links"].split(", "):
            for link in soup.select(selector):
                href = link.get('href')
                if href:
                    full_url = urljoin(base_url, href)
                    doc_links.add(full_url)
        
        # Method 2: Table-based extraction with enhanced selectors
        for row in soup.select(config["document_selectors"]["table_rows"]):
            for link in row.find_all('a', href=True):
                href = link.get('href')
                if href and any(ext in href.lower() for ext in ['.pdf', '.doc', '.docx', 'document', 'fileEntryId']):
                    full_url = urljoin(base_url, href)
                    doc_links.add(full_url)
        
        # Method 3: Text-based link discovery with enhanced keywords
        for link in soup.find_all('a', href=True):
            href = link.get('href')
            link_text = link.get_text(strip=True).lower()
            
            if href and any(keyword in link_text for keyword in [
                'download', 'view', 'report', 'policy', 'document', 'pdf', 
                'regulation', 'circular', 'guideline', 'notification', 'read more'
            ]):
                full_url = urljoin(base_url, href)
                doc_links.add(full_url)
        
        # Method 4: JavaScript onclick and data attributes
        for element in soup.find_all(['a', 'button', 'div'], attrs={'onclick': True}):
            onclick = element.get('onclick', '')
            if any(keyword in onclick.lower() for keyword in ['document', 'pdf', 'download']):
                # Extract URLs from JavaScript
                url_match = re.search(r'["\']([^"\']*(?:\.pdf|\.doc|document-detail|document-viewer|fileEntryId)[^"\']*)["\']', onclick)
                if url_match:
                    url = url_match.group(1)
                    full_url = urljoin(base_url, url)
                    doc_links.add(full_url)
        
        return list(doc_links)
    
    def scrape_page_simple(self, url: str, config: Dict) -> str:
        """Simple scraping using requests only"""
        try:
            logger.info(f"Scraping with requests: {url}")
            response = requests.get(url, timeout=30, headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            })
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Extract title
            title = soup.find('title')
            title_text = title.get_text().strip() if title else "No title"
            
            # Extract content using multiple selectors
            content_text = ""
            for selector in config["document_selectors"]["content_area"].split(", "):
                content_div = soup.select_one(selector)
                if content_div:
                    content_text = content_div.get_text(separator=' ', strip=True)
                    break
            
            if not content_text:
                body = soup.find('body')
                if body:
                    content_text = body.get_text(separator=' ', strip=True)
            
            # Clean content
            content_text = re.sub(r'\s+', ' ', content_text).strip()
            
            # Extract document links
            doc_links = self.extract_all_document_links(soup, config["base_url"], config)
            
            return {
                'title': title_text,
                'content': content_text,
                'doc_links': doc_links,
                'soup': soup
            }
            
        except Exception as e:
            logger.error(f"Error scraping {url}: {e}")
            return None
    
    def clear_query_state(self):
        """Clear all query-specific state to prevent contamination between queries"""
        self.visited_urls.clear()
        self.documents.clear()
        self.pdf_cache.clear()
        self.query_state = {
            'visited_urls': set(),
            'found_documents': [],
            'document_cache': {},
            'last_query': self.current_query
        }
        logger.info(f"Cleared query state. Previous query: '{self.query_state['last_query']}'")
    
    def calculate_relevance_score(self, text: str, query: str) -> float:
        """Calculate relevance score between text and query with improved accuracy"""
        if not query.strip():
            return 0.1  # Low base score if no query
        
        query_lower = query.lower().strip()
        text_lower = text.lower().strip()
        
        if not text_lower:
            return 0.0
        
        score = 0.0
        query_words = [word for word in query_lower.split() if len(word) > 2]
        
        # Exact phrase match (highest score)
        if query_lower in text_lower:
            score += 20.0
            logger.info(f"Exact phrase match found in: {text[:50]}...")
        
        # Individual word matches with position weighting
        for word in query_words:
            if word in text_lower:
                # Higher score if word appears early in text
                word_pos = text_lower.find(word)
                position_weight = max(1.0, 5.0 - (word_pos / 100))
                score += 3.0 * position_weight
        
        # Specific document patterns (IRDAI)
        if "documentId=" in text_lower and any(word in query_lower for word in ["rules", "regulation", "circular"]):
            score += 10.0
        
        # Year matching (important for regulations)
        import re
        query_years = re.findall(r'\b(20\d{2})\b', query)
        text_years = re.findall(r'\b(20\d{2})\b', text)
        for year in query_years:
            if year in text_years:
                score += 8.0
                logger.info(f"Year match ({year}) found in: {text[:50]}...")
        
        # GSR number matching
        query_gsr = re.findall(r'\bGSR[\s]*\d+', query_lower)
        text_gsr = re.findall(r'\bGSR[\s]*\d+', text_lower)
        for gsr in query_gsr:
            if gsr in text_gsr:
                score += 15.0
                logger.info(f"GSR match ({gsr}) found in: {text[:50]}...")
        
        # Specific term matching with high weights
        high_value_terms = {
            "motor vehicle": 15.0,
            "third party": 12.0,
            "base premium": 10.0,
            "liability": 8.0,
            "obligatory cession": 15.0,
            "financial year": 8.0,
            "irdai": 5.0,
            "insurance": 3.0
        }
        
        for term, weight in high_value_terms.items():
            if term in query_lower and term in text_lower:
                score += weight
                logger.info(f"High-value term '{term}' match found in: {text[:50]}...")
        
        # Penalize generic/irrelevant content
        generic_penalties = ["media gallery", "photo gallery", "about us", "contact", "general information"]
        for penalty_term in generic_penalties:
            if penalty_term in text_lower and not any(word in text_lower for word in query_words):
                score = max(0, score - 10.0)
        
        # Normalize score to reasonable range
        max_possible_score = 100.0
        normalized_score = min(score / max_possible_score, 1.0)
        
        if normalized_score > 0.1:
            logger.info(f"Relevance score {normalized_score:.3f} for query '{query}' in text: {text[:100]}...")
        
        return normalized_score
    
    def determine_intelligent_route(self, query: str) -> List[str]:
        """Intelligently determine which IRDAI sections to search based on query"""
        query_lower = query.lower().strip()
        
        # Score each route type based on keyword matches
        route_scores = {}
        config = self.website_configs["irdai"]["intelligent_routing"]
        
        for route_type, route_info in config.items():
            score = 0
            for keyword in route_info["keywords"]:
                if keyword in query_lower:
                    # Give higher score for exact matches and longer keywords
                    score += len(keyword.split()) * 2
                    if query_lower == keyword:
                        score += 10  # Bonus for exact match
            route_scores[route_type] = score
        
        # Sort routes by relevance score
        sorted_routes = sorted(route_scores.items(), key=lambda x: x[1], reverse=True)
        
        # Determine which routes to use
        selected_urls = []
        max_score = sorted_routes[0][1] if sorted_routes else 0
        
        if max_score > 0:
            # Use the top scoring routes
            for route_type, score in sorted_routes:
                if score >= max_score * 0.5:  # Use routes with at least 50% of max score
                    selected_urls.extend(config[route_type]["primary_urls"])
                    logger.info(f"🎯 Selected route '{route_type}' (score: {score}) for query: '{query}'")
        
        # Remove duplicates while preserving order
        seen = set()
        unique_urls = []
        for url in selected_urls:
            if url not in seen:
                seen.add(url)
                unique_urls.append(url)
        
        # If no intelligent route found, fall back to comprehensive search
        if not unique_urls:
            logger.warning(f"⚠️ No intelligent route found for '{query}', using comprehensive search")
            unique_urls = self.website_configs["irdai"]["start_pages"]
        
        return unique_urls[:4]  # Limit to top 4 most relevant URLs

    def extract_irdai_documents_enhanced(self, soup: BeautifulSoup, base_url: str, query: str = "") -> List[Dict]:
        """Enhanced IRDAI document extraction with recursive backtracking and exact matching"""
        documents = []
        logger.info(f"🔍 Extracting IRDAI documents for query: '{query}'")
        
        # CRITICAL: Exact title matching logic
        query_normalized = self.normalize_title(query)
        
        # Enhanced Pattern 1: Table-based extraction with improved accuracy
        tables_processed = 0
        for table in soup.find_all('table'):
            rows = table.find_all('tr')
            tables_processed += 1
            logger.info(f"📋 Processing table {tables_processed} with {len(rows)} rows")
            
            for row_idx, row in enumerate(rows):
                if row_idx == 0:  # Skip header row
                    continue
                
                cells = row.find_all(['td', 'th'])
                if len(cells) < 2:
                    continue
                
                title = ""
                link_url = ""
                document_id = ""
                additional_info = ""
                
                # Enhanced extraction methods
                # Method 1: Look for specific IRDAI table classes
                for cell in cells:
                    cell_classes = cell.get('class', [])
                    cell_text = cell.get_text(strip=True)
                    
                    # Enhanced class-based extraction
                    if any(cls in cell_classes for cls in ['table-col-shortDesc', 'document-title', 'title-cell']):
                        if len(cell_text) > len(title):
                            title = cell_text
                    elif any(cls in cell_classes for cls in ['table-col-subTitle', 'document-link', 'link-cell']):
                        link_elem = cell.find('a', href=True)
                        if link_elem:
                            link_url = link_elem.get('href')
                            if 'documentId=' in link_url:
                                doc_id_match = re.search(r'documentId=(\d+)', link_url)
                                if doc_id_match:
                                    document_id = doc_id_match.group(1)
                
                # Method 2: Intelligent cell analysis for unstructured tables
                if not title or not link_url:
                    cell_texts = []
                    cell_links = []
                    
                    for cell in cells:
                        cell_text = cell.get_text(strip=True)
                        cell_texts.append(cell_text)
                        
                        # Find all links in cell
                        for link in cell.find_all('a', href=True):
                            href = link.get('href')
                            if href:
                                cell_links.append({
                                    'href': href,
                                    'text': link.get_text(strip=True),
                                    'cell_text': cell_text
                                })
                    
                    # Find the most descriptive text as title
                    potential_titles = []
                    for text in cell_texts:
                        # Filter out dates, numbers, and short text
                        if (len(text) > 20 and 
                            not text.isdigit() and 
                            not re.match(r'^\d{1,2}[-/]\d{1,2}[-/]\d{4}$', text) and
                            not re.match(r'^\d+$', text)):
                            potential_titles.append(text)
                    
                    # Choose the longest meaningful title
                    if potential_titles:
                        title = max(potential_titles, key=len)
                    
                    # Find the best document link
                    document_links = [link for link in cell_links 
                                    if 'document-detail' in link['href'] and 'documentId=' in link['href']]

                    if document_links:
                        best_link = document_links[0]  # Take first document link
                        link_url = best_link['href']
                        doc_id_match = re.search(r'documentId=(\d+)', link_url)
                        if doc_id_match:
                            document_id = doc_id_match.group(1)
                        
                        # If link has better title, use it
                        if best_link['text'] and len(best_link['text']) > 10:
                            if not title or len(best_link['text']) > len(title) * 0.8:
                                title = best_link['text']
                
                # Method 3: Enhanced exact title matching with fuzzy matching
                if title and link_url and document_id:
                    title_normalized = self.normalize_title(title)
                    
                    # Multiple matching strategies
                    exact_match = False
                    match_score = 0
                    
                    # Strategy 1: Exact normalized match
                    if self.is_exact_title_match(query_normalized, title_normalized):
                        exact_match = True
                        match_score = 1.0
                        logger.info(f"🎯 EXACT MATCH (Strategy 1): {title} (ID: {document_id})")
                    
                    # Strategy 2: Key phrase matching for Acts
                    elif "act" in query_normalized and "act" in title_normalized:
                        query_words = set(query_normalized.split())
                        title_words = set(title_normalized.split())
                        common_words = query_words.intersection(title_words)
                        
                        # Special handling for amendment acts
                        if ("amendment" in query_normalized and "amendment" in title_normalized and
                            len(common_words) >= 3):
                            exact_match = True
                            match_score = 0.95
                            logger.info(f"🎯 EXACT MATCH (Strategy 2 - Amendment Act): {title} (ID: {document_id})")
                        
                        # Check for year matching in acts
                        query_years = re.findall(r'\b(20\d{2})\b', query_normalized)
                        title_years = re.findall(r'\b(20\d{2})\b', title_normalized)
                        if query_years and title_years and any(year in title_years for year in query_years):
                            if len(common_words) >= 2:
                                exact_match = True
                                match_score = 0.9
                                logger.info(f"🎯 EXACT MATCH (Strategy 2 - Year + Act): {title} (ID: {document_id})")
                    
                    # Strategy 3: Fuzzy matching for close matches
                    if not exact_match:
                        relevance_score = self.calculate_relevance_score(title, query)
                        if relevance_score > 0.8:  # Very high relevance
                            exact_match = True
                            match_score = relevance_score
                            logger.info(f"🎯 EXACT MATCH (Strategy 3 - High Relevance): {title} (ID: {document_id})")
                    
                    if exact_match:
                        full_url = urljoin(base_url, link_url)
                        documents.append({
                            'url': full_url,
                            'title': title,
                            'relevance_score': match_score,
                            'extraction_pattern': f'exact_match_strategy',
                            'document_id': document_id,
                            'exact_match': True,
                            'metadata': {
                                'document_id': document_id,
                                'exact_title_match': True,
                                'normalized_title': title_normalized,
                                'normalized_query': query_normalized,
                                'match_score': match_score,
                                'extraction_table': tables_processed
                            }
                        })
                    else:
                        # Add as potential match for fallback
                        relevance_score = self.calculate_relevance_score(title, query)
                        if relevance_score > 0.15:  # Lower threshold for fallback
                            full_url = urljoin(base_url, link_url)
                            documents.append({
                                'url': full_url,
                                'title': title,
                                'relevance_score': relevance_score,
                                'extraction_pattern': 'partial_match',
                                'document_id': document_id,
                                'exact_match': False,
                                'metadata': {
                                    'document_id': document_id,
                                    'exact_title_match': False,
                                    'normalized_title': title_normalized,
                                    'normalized_query': query_normalized
                                }
                            })
        
        # Enhanced Pattern 2: Direct anchor extraction with context analysis
        logger.info("🔍 Analyzing direct document links...")
        for link in soup.find_all('a', href=True):
            href = link.get('href')
            if not href or 'document-detail' not in href or 'documentId=' not in href:
                continue
            
            # Extract document ID
            doc_id_match = re.search(r'documentId=(\d+)', href)
            if not doc_id_match:
                continue
            document_id = doc_id_match.group(1)
            
            # Enhanced title extraction with context
            title = self.extract_title_from_link_with_context(link)
            
            if title and len(title) > 10:
                title_normalized = self.normalize_title(title)
                
                # Check if we already have this document ID
                existing_doc = next((doc for doc in documents if doc.get('document_id') == document_id), None)
                
                # Enhanced matching for direct links
                exact_match = self.is_exact_title_match(query_normalized, title_normalized)
                
                if exact_match and not existing_doc:
                    full_url = urljoin(base_url, href)
                    documents.append({
                        'url': full_url,
                        'title': title,
                        'relevance_score': 1.0,
                        'extraction_pattern': 'exact_match_direct_enhanced',
                        'document_id': document_id,
                        'exact_match': True,
                        'metadata': {
                            'document_id': document_id,
                            'exact_title_match': True,
                            'normalized_title': title_normalized,
                            'normalized_query': query_normalized
                        }
                    })
                    logger.info(f"🎯 EXACT MATCH (Direct Link): {title} (ID: {document_id})")
        
        # Sort and filter results
        documents.sort(key=lambda x: (not x.get('exact_match', False), -x.get('relevance_score', 0)))
        
        # Log comprehensive results
        exact_matches = [doc for doc in documents if doc.get('exact_match', False)]
        partial_matches = [doc for doc in documents if not doc.get('exact_match', False)]
        
        logger.info(f"📊 Extraction results for '{query}': {len(documents)} total, {len(exact_matches)} exact, {len(partial_matches)} partial")
        
        for i, doc in enumerate(exact_matches[:3]):
            logger.info(f"  ✅ EXACT {i+1}: {doc['title']} (Score: {doc['relevance_score']:.3f}, ID: {doc.get('document_id')})")
        
        for i, doc in enumerate(partial_matches[:2]):
            logger.info(f"  ⚠️ PARTIAL {i+1}: {doc['title']} (Score: {doc['relevance_score']:.3f}, ID: {doc.get('document_id')})")
        
        # Return strategy: Exact matches first, then best partial matches
        if exact_matches:
            return exact_matches[:5]  # Return top 5 exact matches
        elif partial_matches:
            # Filter partial matches to only high-quality ones
            high_quality_partial = [doc for doc in partial_matches if doc['relevance_score'] > 0.3]
            if high_quality_partial:
                return high_quality_partial[:3]
        
        logger.warning(f"❌ No high-quality matches found for query: '{query}'")
        return []

    def extract_title_from_link_with_context(self, link_element) -> str:
        """Enhanced title extraction with surrounding context analysis"""
        title = ""
        
        # Method 1: Text inside special tags
        for tag in ['u', 'strong', 'b', 'em']:
            special_tag = link_element.find(tag)
            if special_tag:
                candidate_title = special_tag.get_text(strip=True)
                if len(candidate_title) > len(title):
                    title = candidate_title
        
        # Method 2: Direct link text
        if not title:
            title = link_element.get_text(strip=True)
        
        # Method 3: Title attribute
        if not title or len(title) < 10:
            title_attr = link_element.get('title', '')
            if len(title_attr) > len(title):
                title = title_attr
        
        # Method 4: Analyze parent elements for context
        if not title or len(title) < 15:
            # Check parent row or cell for better title
            parent = link_element.find_parent(['tr', 'td', 'div', 'li'])
            if parent:
                parent_text = parent.get_text(strip=True)
                
                # Extract meaningful text from parent
                sentences = re.split(r'[.!?]+', parent_text)
                for sentence in sentences:
                    sentence = sentence.strip()
                    if (len(sentence) > 20 and len(sentence) < 200 and
                        not sentence.isdigit() and
                        not re.match(r'^\d{1,2}[-/]\d{1,2}[-/]\d{4}$', sentence)):
                        if len(sentence) > len(title):
                            title = sentence
        
        # Method 5: Look for nearby headings
        if not title or len(title) < 20:
            for heading_tag in ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']:
                nearby_heading = link_element.find_previous(heading_tag) or link_element.find_next(heading_tag)
                if nearby_heading:
                    heading_text = nearby_heading.get_text(strip=True)
                    if len(heading_text) > len(title) and len(heading_text) < 150:
                        title = heading_text
                        break
        
        return title.strip()

    def scrape_irdai_comprehensive(self, query: str = "") -> List[ComprehensiveDocument]:
        """INTELLIGENT IRDAI scraping with smart routing and recursive backtracking"""
        # Clear state for fresh search
        self.clear_query_state()
        self.current_query = query
        
        config = self.website_configs["irdai"]
        all_documents = []
        
        logger.info(f"🧠 Starting INTELLIGENT IRDAI scraping for query: '{query}'")
        
        # Step 1: Determine intelligent routes based on query
        intelligent_urls = self.determine_intelligent_route(query)
        logger.info(f"🎯 Intelligent routing selected {len(intelligent_urls)} priority URLs")
        
        # Step 2: Search priority URLs first
        for priority_url in intelligent_urls:
            page_url = urljoin(config["base_url"], priority_url)
            logger.info(f"🔍 Priority search: {page_url}")
            
            try:
                documents = self.scrape_page_recursive_enhanced(page_url, config, depth=0, query=query, is_priority=True)
                all_documents.extend(documents)
                
                # If we found exact matches in priority search, we can stop
                exact_matches = [doc for doc in documents if doc.metadata.get('exact_match', False)]
                if exact_matches:
                    logger.info(f"🎯 Found {len(exact_matches)} exact matches in priority search, stopping here")
                    break
                
                # Clear visited URLs between priority pages for better coverage
                self.visited_urls.clear()
                
            except Exception as e:
                logger.error(f"Error in priority search {page_url}: {e}")
                continue
            
            time.sleep(2)  # Rate limiting
        
        # Step 3: If no exact matches found, do broader search
        if not any(doc.metadata.get('exact_match', False) for doc in all_documents):
            logger.info("🔄 No exact matches in priority search, expanding search scope...")
            
            remaining_urls = [url for url in config["start_pages"] if url not in intelligent_urls]
            for backup_url in remaining_urls[:2]:  # Limit backup search
                page_url = urljoin(config["base_url"], backup_url)
                logger.info(f"🔍 Backup search: {page_url}")
                
                try:
                    documents = self.scrape_page_recursive_enhanced(page_url, config, depth=0, query=query, is_priority=False)
                    all_documents.extend(documents)
                    
                    # Stop if we find exact matches
                    exact_matches = [doc for doc in documents if doc.metadata.get('exact_match', False)]
                    if exact_matches:
                        logger.info(f"🎯 Found {len(exact_matches)} exact matches in backup search")
                        break
                        
                except Exception as e:
                    logger.error(f"Error in backup search {page_url}: {e}")
                    continue
                
                time.sleep(2)
        
        # Filter and sort results
        if query:
            # Prioritize exact matches
            exact_matches = [doc for doc in all_documents if doc.metadata.get('exact_match', False)]
            partial_matches = [doc for doc in all_documents if not doc.metadata.get('exact_match', False)]
            
            # Filter partial matches by relevance
            good_partial_matches = [doc for doc in partial_matches if doc.metadata.get('page_relevance_score', 0) > 0.1]
            
            # Combine results: exact matches first, then best partial matches
            final_documents = exact_matches + good_partial_matches[:10]  # Limit partial matches
        else:
            final_documents = all_documents
        
        logger.info(f"🎯 INTELLIGENT IRDAI search complete: {len(final_documents)} documents found for '{query}'")
        
        # Log summary
        exact_count = len([doc for doc in final_documents if doc.metadata.get('exact_match', False)])
        partial_count = len(final_documents) - exact_count
        logger.info(f"📊 Results: {exact_count} exact matches, {partial_count} partial matches")
        
        return final_documents

    def scrape_page_recursive_enhanced(self, url: str, config: Dict, depth: int = 0, query: str = "", is_priority: bool = False) -> List[ComprehensiveDocument]:
        """Enhanced recursive scraping with backtracking and intelligent depth control"""
        if depth > config["max_depth"] or url in self.visited_urls:
            return []
        
        self.visited_urls.add(url)
        documents = []
        
        try:
            logger.info(f"🔍 Enhanced scraping (depth {depth}, priority: {is_priority}) for '{query}': {url}")
            
            # Scrape current page
            page_data = self.scrape_page_with_query(url, config, query)
            if not page_data:
                return []
            
            title_text = page_data['title']
            content_text = page_data['content']
            doc_data = page_data['doc_data']
            soup = page_data['soup']
            
            # Check for exact matches
            exact_matches = [doc for doc in doc_data if isinstance(doc, dict) and doc.get('exact_match', False)]
            
            if exact_matches:
                logger.info(f"🎯 Found {len(exact_matches)} EXACT MATCHES on page: {url}")
                
                # Create comprehensive documents for exact matches
                for match in exact_matches:
                    document = ComprehensiveDocument(
                        url=match['url'],
                        title=match['title'],
                        content=f"""
{match['title']}

This document exactly matches your query: "{query}"

Document ID: {match.get('document_id', 'N/A')}
Source: IRDAI Official Website
Last Updated: {match.get('metadata', {}).get('last_updated', 'Current')}
Page Found: {url}

This is an official IRDAI document. Please refer to the document link for complete details.
                        """,
                        source_type=config["source_type"],
                        website=config["base_url"],
                        document_links=[match['url']],
                        metadata={
                            'scraped_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                            'depth': depth,
                            'source_website': config["base_url"],
                            'document_id': match.get('document_id'),
                            'exact_match': True,
                            'query': query,
                            'page_relevance_score': 1.0,
                            'extraction_pattern': match.get('extraction_pattern'),
                            'keywords_found': config["keywords"],
                            'found_on_page': url,
                            'is_priority_search': is_priority
                        }
                    )
                    documents.append(document)
                
                # If exact matches found, reduce recursive depth to avoid unnecessary searching
                if is_priority:
                    return documents  # Stop recursion for priority searches when exact match found
            
            # Create document from page content if relevant
            page_relevance = self.calculate_relevance_score(title_text + " " + content_text[:1000], query)
            
            if page_relevance > 0.1:
                all_doc_links = self.extract_all_document_links(soup, config["base_url"], config)
                
                document = ComprehensiveDocument(
                    url=url,
                    title=title_text,
                    content=content_text[:2000] + "..." if len(content_text) > 2000 else content_text,
                    source_type=config["source_type"],
                    website=config["base_url"],
                    document_links=all_doc_links,
                    metadata={
                        'scraped_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                        'depth': depth,
                        'source_website': config["base_url"],
                        'exact_match': False,
                        'query': query,
                        'page_relevance_score': page_relevance,
                        'keywords_found': config["keywords"],
                        'document_links': all_doc_links,
                        'is_priority_search': is_priority
                    }
                )
                documents.append(document)
            
            # RECURSIVE BACKTRACKING: Continue searching if no exact matches found
            if not exact_matches and depth < config["max_depth"]:
                internal_links = self.extract_internal_links(soup, config["base_url"], url, config)
                
                # Intelligent link filtering for better targeting
                filtered_links = self.filter_relevant_links(internal_links, query, config)
                
                # Limit links based on priority and depth
                max_links = 5 if is_priority else 3
                if depth > 2:
                    max_links = 2  # Reduce at deeper levels
                
                for next_url in filtered_links[:max_links]:
                    if next_url not in self.visited_urls:
                        time.sleep(1)  # Rate limiting
                        sub_documents = self.scrape_page_recursive_enhanced(
                            next_url, config, depth + 1, query, is_priority
                        )
                        documents.extend(sub_documents)
                        
                        # BACKTRACKING: Stop if we found exact matches
                        if any(doc.metadata.get('exact_match', False) for doc in sub_documents):
                            logger.info(f"🎯 Exact match found at depth {depth+1}, stopping recursion")
                            break
            
        except Exception as e:
            logger.error(f"Error in enhanced scraping {url} at depth {depth}: {e}")
        
        return documents

    def filter_relevant_links(self, links: List[str], query: str, config: Dict) -> List[str]:
        """Filter internal links to focus on most relevant ones"""
        if not links:
            return []
        
        scored_links = []
        query_lower = query.lower()
        
        for link in links:
            score = 0
            link_lower = link.lower()
            
            # Score based on URL path relevance
            if "/acts" in link_lower and "act" in query_lower:
                score += 10
            elif "/rules" in link_lower and any(keyword in query_lower for keyword in ["rules", "motor", "vehicle"]):
                score += 10
            elif "/regulations" in link_lower and "regulation" in query_lower:
                score += 8
            elif "/circulars" in link_lower and "circular" in query_lower:
                score += 8
            elif "/notifications" in link_lower and "notification" in query_lower:
                score += 6
            
            # Score based on keyword presence in URL
            for keyword in config["keywords"]:
                if keyword in link_lower:
                    score += 2
            
            # Bonus for specific query terms in URL
            query_words = [word for word in query_lower.split() if len(word) > 3]
            for word in query_words:
                if word in link_lower:
                    score += 3
            
            scored_links.append((link, score))
        
        # Sort by score and return top links
        scored_links.sort(key=lambda x: x[1], reverse=True)
        return [link for link, score in scored_links if score > 0]

    def close_driver(self):
        """Close Selenium WebDriver"""
        if self.driver:
            self.driver.quit()
            self.driver = None
    
    def extract_all_documents(self) -> List[ComprehensiveDocument]:
        """Extract all documents from visited URLs"""
        all_documents = []
        
        for url in self.visited_urls:
            try:
                logger.info(f"Extracting document from: {url}")
                response = requests.get(url, timeout=30)
                response.raise_for_status()
                
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # Extract title
                title = soup.find('title')
                title_text = title.get_text().strip() if title else "No title"
                
                # Extract content
                content = ""
                for selector in self.website_configs["irdai"]["document_selectors"]["content_area"].split(", "):
                    content_div = soup.select_one(selector)
                    if content_div:
                        content = content_div.get_text(separator=' ', strip=True)
                        break
                
                if not content:
                    content = soup.get_text(separator=' ', strip=True)
                
                # Clean content
                content = re.sub(r'\s+', ' ', content).strip()
                
                # Create document object
                document = ComprehensiveDocument(
                    url=url,
                    title=title_text,
                    content=content,
                    source_type="regulatory",
                    website=self.website_configs["irdai"]["base_url"],
                    document_links=[],
                    metadata={
                        'scraped_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                        'depth': 0,
                        'source_website': self.website_configs["irdai"]["base_url"],
                        'content_length': len(content),
                        'document_count': 0,
                        'keywords_found': []
                    }
                )
                
                all_documents.append(document)
            
            except Exception as e:
                logger.error(f"Error extracting document from {url}: {e}")
        
        return all_documents
    
    def save_documents(self, output_file: str = "data/scraped/comprehensive_documents.json"):
        """Save all scraped documents"""
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        
        data_dict = []
        for doc in self.documents:
            data_dict.append({
                'url': doc.url,
                'title': doc.title,
                'content': doc.content,
                'source_type': doc.source_type,
                'website': doc.website,
                'document_links': doc.document_links,
                'metadata': doc.metadata
            })
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(data_dict, f, indent=2, ensure_ascii=False)
        
        logger.info(f"Saved {len(self.documents)} comprehensive documents to {output_file}")

    def create_searchable_content(self, query: str) -> List[ComprehensiveDocument]:
        """Create content that matches specific queries - ONLY for demo mode"""
        if not self.demo_mode:
            logger.info("Demo mode disabled - using real scraping instead of sample content")
            return []
        
        logger.info("Demo mode enabled - returning sample content")
        # IRDAI Sample Documents with proper IRDAI links
        irdai_docs = [
            {
                "title": "IRDAI (Maintenance of Information by the Regulated Entities and Sharing of Information by the Authority), Regulations 2025",
                "content": """
IRDAI (Maintenance of Information by the Regulated Entities and Sharing of Information by the Authority), Regulations 2025

Reference Number: IRDAI/Reg/4/211/2025
Last Updated: 10-01-2025

CHAPTER I - PRELIMINARY
1. Short title and commencement
2. Definitions and scope
3. Application to regulated entities

CHAPTER II - MAINTENANCE OF INFORMATION
4. General obligations for information maintenance
5. Categories of information to be maintained
6. Record keeping requirements
7. Data quality and accuracy standards

CHAPTER III - SHARING OF INFORMATION
8. Information sharing framework
9. Conditions and safeguards
10. International cooperation

These regulations establish comprehensive requirements for regulated entities to maintain accurate information and enable appropriate information sharing by IRDAI for regulatory purposes.

Key provisions include:
- Mandatory information maintenance by insurers
- Data quality standards and verification procedures
- Framework for information sharing between IRDAI and other regulatory bodies
- Compliance requirements and penalties for non-compliance
- Implementation timeline and transition provisions

The regulations apply to all regulated entities including life insurers, general insurers, reinsurers, insurance brokers, and other intermediaries.

This regulation is fundamental to IRDAI's oversight function and ensures comprehensive information management across the insurance sector.
                """,
                "document_links": [
                    "https://irdai.gov.in/document-detail?documentId=6540652",
                    "https://irdai.gov.in/regulations/maintenance-information-regulations-2025",
                    "https://irdai.gov.in/assets/docs/regulations/IRDAI-Maintenance-Information-Regulations-2025.pdf",
                    "https://irdai.gov.in/notifications/regulation-4-211-2025"
                ],
                "metadata": {
                    "reference_number": "IRDAI/Reg/4/211/2025",
                    "document_id": "6540652",
                    "regulation_type": "Information Maintenance"
                }
            },
            {
                "title": "IRDAI Master Circular on Corporate Governance Guidelines for Insurers",
                "content": """
IRDAI Master Circular on Corporate Governance Guidelines for Insurers

Reference Number: IRDAI/CGGL/001/2025
Effective Date: 01-01-2025

This circular consolidates all guidelines related to corporate governance requirements for insurance companies including board composition, risk management, and disclosure requirements.

Key requirements include:
- Independent directors requirements (minimum 50% of board)
- Board committees structure (Audit, Risk, Nomination & Remuneration)
- Risk management framework and chief risk officer appointment
- Disclosure and transparency norms
- Fit and proper criteria for key management personnel
- Internal audit and compliance framework

Board Composition:
- Minimum 6 directors, maximum 15 directors
- At least 50% independent directors
- Chairman should be independent director
- CEO/MD cannot be Chairman

Risk Management:
- Comprehensive risk management policy
- Risk appetite framework
- Regular risk assessment and reporting
- Stress testing requirements

Disclosure Requirements:
- Quarterly governance reports
- Annual corporate governance report
- Related party transaction disclosures
- Material information disclosure to stakeholders

These corporate governance guidelines ensure that insurance companies maintain the highest standards of governance and transparency in their operations.
                """,
                "document_links": [
                    "https://irdai.gov.in/document-detail?documentId=5432187",
                    "https://irdai.gov.in/circulars/corporate-governance-guidelines",
                    "https://irdai.gov.in/assets/docs/circulars/Corporate-Governance-Guidelines-Master-Circular.pdf",
                    "https://irdai.gov.in/regulations/corporate-governance-framework"
                ],
                "metadata": {
                    "circular_type": "Corporate Governance",
                    "document_id": "5432187",
                    "reference_number": "IRDAI/CGGL/001/2025"
                }
            },
            {
                "title": "IRDAI Notification - Insurance Regulatory and Development Authority Act Implementation",
                "content": """
IRDAI Notification - Insurance Regulatory and Development Authority Act Implementation

Reference Number: IRDAI/Reg/4/211/2025
Notification Date: 15-01-2025

In exercise of the powers conferred by section 114A of the Insurance Act, 1938 and section 26 of the Insurance Regulatory and Development Authority Act, 1999, the Authority hereby notifies the following regulations:

1. APPLICABILITY
These regulations shall apply to all regulated entities including:
- Life insurance companies
- General insurance companies  
- Reinsurance companies
- Insurance brokers and intermediaries
- Third party administrators

2. INFORMATION MAINTENANCE REQUIREMENTS
All regulated entities shall maintain the following information:
- Financial statements and records
- Policy holder information and claims data
- Regulatory compliance documentation
- Risk management reports
- Corporate governance records

3. SHARING FRAMEWORK
The Authority may share information with:
- Other financial sector regulators
- Government agencies as per law
- International regulatory bodies through MoUs
- Law enforcement agencies for investigation purposes

4. COMPLIANCE TIMELINE
- Entities have 90 days to implement systems
- Quarterly compliance reports required
- Annual certification by appointed actuary/auditor
- Penalties for non-compliance as per schedule

This notification supersedes all previous circulars on information maintenance and sharing. The implementation of these regulations is crucial for maintaining the integrity and transparency of the insurance sector under IRDAI's regulatory oversight.
                """,
                "document_links": [
                    "https://irdai.gov.in/notifications/information-sharing-framework-2025",
                    "https://irdai.gov.in/document-detail?documentId=6540651",
                    "https://irdai.gov.in/assets/docs/notifications/IRDAI-Information-Sharing-Notification-2025.pdf",
                    "https://irdai.gov.in/regulations/authority-act-implementation"
                ],
                "metadata": {
                    "notification_type": "Regulatory Framework",
                    "reference_number": "IRDAI/Reg/4/211/2025",
                    "document_id": "6540651"
                }
            }
        ]
        
        # LIC Sample Documents
        lic_docs = [
            {
                "title": "LIC Annual Report 2024-25",
                "content": """
Life Insurance Corporation of India - Annual Report 2024-25

Chairman's Message:
LIC continues to be the market leader in life insurance in India with comprehensive coverage and customer-centric approach.

Key Highlights:
- Total premium income: Rs. 2,85,000 crores
- New business premium: Rs. 95,000 crores
- Individual policies issued: 1.2 crore
- Corporate governance initiatives and digital transformation

Business Operations:
LIC offers a wide range of life insurance products including term insurance, endowment plans, pension plans, and unit-linked insurance plans.
                """,
                "document_links": [
                    "https://www.licindia.in/documents/annual-report-2024-25.pdf",
                    "https://www.licindia.in/investor-relations/annual-reports"
                ],
                "metadata": {
                    "report_type": "Annual Report",
                    "year": "2024-25"
                }
            },
            {
                "title": "LIC Corporate Governance Policy",
                "content": """
LIC Corporate Governance Policy

LIC is committed to maintaining highest standards of corporate governance through:

Board Structure:
- Independent directors representation
- Board committees for audit, risk, and nomination
- Regular board meetings and performance evaluation

Risk Management:
- Comprehensive risk management framework
- Investment risk assessment
- Operational risk controls

Stakeholder Engagement:
- Transparent communication with policyholders
- Regular disclosure of financial performance
- Customer grievance redressal mechanism
                """,
                "document_links": [
                    "https://www.licindia.in/documents/corporate-governance-policy.pdf",
                    "https://www.licindia.in/corporate-governance"
                ],
                "metadata": {
                    "policy_type": "Corporate Governance"
                }
            }
        ]
        
        # HDFC Life Sample Documents
        hdfc_docs = [
            {
                "title": "HDFC Life Annual Report 2024-25",
                "content": """
HDFC Life Insurance Company Limited - Annual Report 2024-25

Managing Director's Review:
HDFC Life continues to strengthen its position as one of India's leading private life insurers with focus on innovation and customer experience.

Financial Performance:
- Total premium income: Rs. 55,000 crores
- New business premium: Rs. 18,000 crores
- Assets under management: Rs. 2,10,000 crores

Product Portfolio:
- Individual protection plans
- Savings and investment plans
- Retirement solutions
- Group insurance products

The company maintains strong solvency ratio and continues digital transformation initiatives.
                """,
                "document_links": [
                    "https://www.hdfclife.com/content/dam/hdfclifeinsurancecompany/about-us/annual-report-2024-25.pdf",
                    "https://www.hdfclife.com/about-us/investor-relations/annual-reports"
                ],
                "metadata": {
                    "report_type": "Annual Report",
                    "company": "HDFC Life"
                }
            }
        ]
        
        # New India Assurance Sample Documents
        new_india_docs = [
            {
                "title": "New India Assurance Surveyor Management Policy 2025",
                "content": """
The New India Assurance Company Limited - Surveyor Management Policy 2025

Objective:
To establish comprehensive guidelines for empanelment, management, and performance evaluation of surveyors.

Surveyor Categories:
1. Individual Surveyors
2. Surveying Companies
3. Specialized Surveyors (Marine, Aviation, etc.)

Empanelment Process:
- Qualification requirements
- Experience criteria
- Application and evaluation process
- Renewal procedures

Performance Monitoring:
- Quality assessment parameters
- Customer feedback mechanism
- Performance rating system
- Corrective action framework

The policy ensures efficient claim settlement through qualified surveyor network.
                """,
                "document_links": [
                    "https://www.newindia.co.in/assets/docs/surveyor_management_policy/SURVEYORS-MANAGEMENT-POLICY-2025.pdf",
                    "https://www.newindia.co.in/assets/docs/surveyor_management_policy/Application-Form-empanelment-SMP-25-26.docx"
                ],
                "metadata": {
                    "policy_type": "Surveyor Management",
                    "year": "2025"
                }
            }
        ]
        
        # Combine all documents
        all_sample_docs = irdai_docs + lic_docs + hdfc_docs + new_india_docs
        
        # Convert to ComprehensiveDocument objects
        documents = []
        for i, doc_data in enumerate(all_sample_docs):
            
            # Determine source type and website
            if "irdai.gov.in" in doc_data["document_links"][0].lower():
                source_type = "regulatory"
                website = "https://irdai.gov.in"
            elif "licindia" in doc_data["document_links"][0].lower():
                source_type = "life_insurance"
                website = "https://www.licindia.in"
            elif "hdfclife" in doc_data["document_links"][0].lower():
                source_type = "life_insurance"
                website = "https://www.hdfclife.com"
            else:
                source_type = "general_insurance"
                website = "https://www.newindia.co.in"
            
            document = ComprehensiveDocument(
                url=doc_data["document_links"][0],
                title=doc_data["title"],
                content=doc_data["content"],
                source_type=source_type,
                website=website,
                document_links=doc_data["document_links"],
                metadata={
                    'scraped_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                    'depth': 0,
                    'source_website': website,
                    'content_length': len(doc_data["content"]),
                    'document_count': len(doc_data["document_links"]),
                    'keywords_found': ["irdai", "regulation", "authority", "insurance"] if "irdai" in website else [],
                    'document_links': doc_data["document_links"],  # Ensure document_links are in metadata
                    **doc_data["metadata"]
                }
            )
            
            documents.append(document)
        
        return documents

    def normalize_title(self, title: str) -> str:
        """Normalize title for comparison"""
        if not title:
            return ""
        
        # Convert to lowercase and strip
        normalized = title.lower().strip()
        
        # Remove extra whitespace
        normalized = re.sub(r'\s+', ' ', normalized)
        
        # Remove common punctuation that might vary
        normalized = re.sub(r'[,\.;:\-_\(\)\[\]]+', ' ', normalized)
        
        # Remove extra spaces again
        normalized = re.sub(r'\s+', ' ', normalized).strip()
        
        return normalized
    
    def is_exact_title_match(self, query_normalized: str, title_normalized: str) -> bool:
        """Check if title exactly matches the query"""
        if not query_normalized or not title_normalized:
            return False
        
        # Direct exact match
        if query_normalized == title_normalized:
            return True
        
        # Check if all significant words from query are in title in same order
        query_words = [word for word in query_normalized.split() if len(word) > 2]
        title_words = title_normalized.split()
        
        if len(query_words) == 0:
            return False
        
        # For very specific documents, require high word overlap
        word_matches = 0
        for query_word in query_words:
            if query_word in title_words:
                word_matches += 1
        
        # Require at least 80% of significant words to match
        match_ratio = word_matches / len(query_words)
        
        # For financial year documents, also check year specifically
        if "financial year" in query_normalized and "financial year" in title_normalized:
            # Extract years from both
            query_years = re.findall(r'\b20\d{2}\b', query_normalized)
            title_years = re.findall(r'\b20\d{2}\b', title_normalized)
            
            if query_years and title_years:
                year_match = any(year in title_years for year in query_years)
                if match_ratio >= 0.7 and year_match:
                    return True
        
        # For other documents, require higher match ratio
        return match_ratio >= 0.85

    def scrape_page_with_query(self, url: str, config: Dict, query: str = "") -> Dict:
        """Scrape page with query-aware document extraction"""
        try:
            logger.info(f"Scraping with query '{query}': {url}")
            response = requests.get(url, timeout=30, headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebDriver/537.36'
            })
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Extract title
            title = soup.find('title')
            title_text = title.get_text().strip() if title else "No title"
            
            # Extract content using multiple selectors
            content_text = ""
            for selector in config["document_selectors"]["content_area"].split(", "):
                content_div = soup.select_one(selector)
                if content_div:
                    content_text = content_div.get_text(separator=' ', strip=True)
                    break
            
            if not content_text:
                body = soup.find('body')
                if body:
                    content_text = body.get_text(separator=' ', strip=True)
            
            # Clean content
            content_text = re.sub(r'\s+', ' ', content_text).strip()
            
            # Extract documents with enhanced IRDAI extraction
            if config.get("base_url") == "https://irdai.gov.in":
                doc_data = self.extract_irdai_documents_enhanced(soup, config["base_url"], query)
            else:
                doc_data = self.extract_all_document_links_with_query(soup, config["base_url"], config, query)
            
            return {
                'title': title_text,
                'content': content_text,
                'doc_data': doc_data,
                'soup': soup
            }
            
        except Exception as e:
            logger.error(f"Error scraping {url}: {e}")
            return None

    def extract_all_document_links_with_query(self, soup: BeautifulSoup, base_url: str, config: Dict, query: str = "") -> List[Dict]:
        """Extract document links with query-based filtering and scoring"""
        doc_data = []
        
        # Method 1: Direct document links using enhanced selectors
        for selector in config["document_selectors"]["document_links"].split(", "):
            for link in soup.select(selector):
                href = link.get('href')
                if href:
                    full_url = urljoin(base_url, href)
                    title = link.get_text(strip=True) or link.get('title', '') or "Document"
                    relevance_score = self.calculate_relevance_score(title, query)
                    
                    doc_data.append({
                        'url': full_url,
                        'title': title,
                        'relevance_score': relevance_score,
                        'extraction_pattern': 'direct_selector'
                    })
        
        # Method 2: Table-based extraction with enhanced selectors
        for row in soup.select(config["document_selectors"]["table_rows"]):
            for link in row.find_all('a', href=True):
                href = link.get('href')
                if href and any(ext in href.lower() for ext in ['.pdf', '.doc', '.docx', 'document', 'fileEntryId']):
                    full_url = urljoin(base_url, href)
                    title = link.get_text(strip=True) or row.get_text(strip=True)[:100] or "Document"
                    relevance_score = self.calculate_relevance_score(title, query)
                    
                    doc_data.append({
                        'url': full_url,
                        'title': title,
                        'relevance_score': relevance_score,
                        'extraction_pattern': 'table_based'
                    })
        
        return doc_data

    def scrape_all_websites_comprehensive(self, query: str = "") -> List[ComprehensiveDocument]:
        """Scrape ALL 4 websites comprehensively with intelligent routing and query awareness"""
        all_documents = []
        self.current_query = query
        
        logger.info(f"🌐 Starting comprehensive scraping of all websites for query: '{query}'")
        
        # Only use sample content if in demo mode
        if self.demo_mode:
            sample_documents = self.create_searchable_content(query)
            all_documents.extend(sample_documents)
            logger.info(f"Demo mode: Added {len(sample_documents)} sample documents")
        else:
            # Real scraping for all websites
            for website_name, config in self.website_configs.items():
                logger.info(f"🔍 Starting comprehensive scraping of {website_name}")
                
                try:
                    if website_name == "irdai":
                        # Use specialized IRDAI scraping with intelligent routing
                        documents = self.scrape_irdai_comprehensive(query)
                        all_documents.extend(documents)
                    else:
                        # Start with main pages for other websites
                        for search_page in config["search_pages"]:
                            page_url = urljoin(config["base_url"], search_page)
                            
                            try:
                                documents = self.scrape_page_recursive_enhanced(page_url, config, depth=0, query=query, is_priority=False)
                                all_documents.extend(documents)
                                time.sleep(2)  # Rate limiting between pages
                            except Exception as e:
                                logger.error(f"Error scraping {page_url}: {e}")
                                continue  # Continue with next page instead of stopping
                    
                    logger.info(f"✅ Completed {website_name}: Found {len([d for d in all_documents if d.website == config['base_url']])} documents")
                    
                except Exception as e:
                    logger.error(f"Error scraping website {website_name}: {e}")
                    continue  # Continue with next website
        
        # Final sorting by relevance if query provided
        if query and not self.demo_mode:
            # Filter documents that have some relevance
            relevant_documents = [doc for doc in all_documents if doc.metadata.get('page_relevance_score', 0) > 0.05]
            relevant_documents.sort(key=lambda doc: doc.metadata.get('page_relevance_score', 0), reverse=True)
            all_documents = relevant_documents[:50]  # Keep top 50 most relevant documents
        
        self.documents = all_documents
        logger.info(f"🎯 Comprehensive scraping complete: {len(all_documents)} total documents found")
        
        return all_documents

def main():
    """Test comprehensive scraper with real query support"""
    print("🔍 Testing comprehensive scraper with real query support...")
    
    # Create scraper without Selenium to avoid Chrome driver issues
    scraper = ComprehensiveScraper(use_selenium=False)
    
    # Test with a real query
    test_query = "ULIP 2023"
    print(f"🔎 Testing query: '{test_query}'")
    
    try:
        # Test real scraping (not demo mode) - explicitly set demo_mode to False
        scraper.demo_mode = False
        print(f"🔧 Demo mode explicitly disabled: {scraper.demo_mode}")
        documents = scraper.scrape_all_websites_comprehensive(test_query)
        
        print(f"✅ Found {len(documents)} documents for query '{test_query}'")
        
        # Filter out low-relevance results for better display
        relevant_documents = [doc for doc in documents if doc.metadata.get('page_relevance_score', 0) > 3.0]
        
        # Show top results
        print(f"\n📊 Top Relevant Results for '{test_query}' (score > 3.0):")
        for i, doc in enumerate(relevant_documents[:10], 1):
            relevance = doc.metadata.get('page_relevance_score', 0)
            print(f"{i}. {doc.title} (Score: {relevance:.2f})")
            print(f"   URL: {doc.url}")
            print(f"   Website: {doc.website}")
            if doc.metadata.get('relevant_documents'):
                print(f"   Relevant docs: {len(doc.metadata['relevant_documents'])}")
            print()
        
        if not relevant_documents:
            print("❌ No highly relevant documents found. Showing all results:")
            for i, doc in enumerate(documents[:5], 1):
                relevance = doc.metadata.get('page_relevance_score', 0)
                print(f"{i}. {doc.title} (Score: {relevance:.2f})")
                print(f"   URL: {doc.url}")
        
        # Test demo mode as well for comparison
        print(f"\n🧪 Testing demo mode for comparison:")
        scraper.demo_mode = True
        demo_documents = scraper.scrape_all_websites_comprehensive(test_query)
        print(f"Demo mode: {len(demo_documents)} sample documents")
        
        # Save the real results (not demo)
        scraper.demo_mode = False
        scraper.documents = documents
        scraper.save_documents()
        
    finally:
        scraper.close_driver()

if __name__ == "__main__":
    main()