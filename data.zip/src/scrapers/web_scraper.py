import requests
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin, urlparse
import time
import json
import os
import re
from typing import Dict, List, Set, Optional
from dataclasses import dataclass
from loguru import logger
from config import Config

@dataclass
class ScrapedContent:
    url: str
    title: str
    content: str
    source_type: str
    document_links: List[str]
    metadata: Dict

class WebScraper:
    def __init__(self):
        self.config = Config()
        self.visited_urls: Set[str] = set()
        self.scraped_data: List[ScrapedContent] = []
        self.driver = None
        
    def setup_driver(self):
        """Initialize Selenium WebDriver"""
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--window-size=1920,1080")
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        chrome_options.add_experimental_option('useAutomationExtension', False)
        
        # Fix: Use ChromeDriverManager properly
        service = webdriver.chrome.service.Service(ChromeDriverManager().install())
        self.driver = webdriver.Chrome(service=service, options=chrome_options)
        
        # Execute script to prevent detection
        self.driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        
    def close_driver(self):
        """Close Selenium WebDriver"""
        if self.driver:
            self.driver.quit()
            self.driver = None
            
    def get_page_content(self, url: str, use_selenium: bool = False) -> Optional[BeautifulSoup]:
        """Get page content using requests or selenium"""
        try:
            if use_selenium:
                if not self.driver:
                    self.setup_driver()
                    
                self.driver.get(url)
                WebDriverWait(self.driver, 10).until(
                    EC.presence_of_element_located((By.TAG_NAME, "body"))
                )
                html = self.driver.page_source
                return BeautifulSoup(html, 'html.parser')
            else:
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
                }
                response = requests.get(url, headers=headers, timeout=self.config.REQUEST_TIMEOUT)
                response.raise_for_status()
                return BeautifulSoup(response.content, 'html.parser')
                
        except Exception as e:
            logger.error(f"Error fetching {url}: {e}")
            return None
            
    def extract_links(self, soup: BeautifulSoup, base_url: str, priority_paths: List[str]) -> List[str]:
        """Extract relevant links from the page"""
        links = []
        
        # Find all links
        for link in soup.find_all('a', href=True):
            href = link.get('href')
            if not href:
                continue
                
            # Convert relative URLs to absolute
            absolute_url = urljoin(base_url, href)
            
            # Check if link is relevant
            if self.is_relevant_link(absolute_url, base_url, priority_paths):
                links.append(absolute_url)
                
        return list(set(links))
        
    def is_relevant_link(self, url: str, base_url: str, priority_paths: List[str]) -> bool:
        """Check if a link is relevant for scraping"""
        parsed_url = urlparse(url)
        parsed_base = urlparse(base_url)
        
        # Must be from same domain
        if parsed_url.netloc != parsed_base.netloc:
            return False
            
        # Skip file downloads initially
        if url.lower().endswith(('.pdf', '.doc', '.docx', '.xls', '.xlsx')):
            return False
            
        # Check if URL matches priority paths
        for path in priority_paths:
            if path in url.lower():
                return True
                
        # Check for common regulatory/corporate keywords
        keywords = ['regulation', 'circular', 'guideline', 'annual', 'report', 
                   'governance', 'investor', 'policy', 'act', 'amendment']
        
        return any(keyword in url.lower() for keyword in keywords)
        
    def extract_document_links(self, soup: BeautifulSoup, base_url: str) -> List[str]:
        """Extract document links (PDF, DOC, etc.) and document detail pages"""
        doc_links = []
        
        # Find direct document links (PDFs, DOCs, etc.)
        for link in soup.find_all('a', href=True):
            href = link.get('href')
            if href:
                # Check for direct document downloads
                if any(ext in href.lower() for ext in ['.pdf', '.doc', '.docx', '.xls', '.xlsx']):
                    doc_links.append(urljoin(base_url, href))
                
                # Check for document detail pages (IRDAI specific)
                elif 'document-detail' in href.lower():
                    doc_links.append(urljoin(base_url, href))
                
                # Check for document viewer pages
                elif any(pattern in href.lower() for pattern in ['documentid=', 'docid=', 'fileid=']):
                    doc_links.append(urljoin(base_url, href))
        
        # Also check for links in table rows (common for document listings)
        for table in soup.find_all('table'):
            for row in table.find_all('tr'):
                for link in row.find_all('a', href=True):
                    href = link.get('href')
                    if href:
                        # Document detail pages
                        if 'document-detail' in href.lower():
                            doc_links.append(urljoin(base_url, href))
                        # Direct document links
                        elif any(ext in href.lower() for ext in ['.pdf', '.doc', '.docx']):
                            doc_links.append(urljoin(base_url, href))
        
        # Check for JavaScript-based document links in onclick attributes
        for element in soup.find_all(['a', 'button', 'div'], onclick=True):
            onclick = element.get('onclick', '')
            if 'document' in onclick.lower():
                # Extract document IDs from JavaScript
                import re
                doc_id_match = re.search(r'documentId[\'"]?\s*:\s*[\'"]?(\d+)', onclick)
                if doc_id_match:
                    doc_id = doc_id_match.group(1)
                    doc_links.append(f"{base_url}/document-detail?documentId={doc_id}")
        
        return list(set(doc_links))  # Remove duplicates
        
    def clean_text(self, text: str) -> str:
        """Clean extracted text"""
        # Remove extra whitespace
        text = ' '.join(text.split())
        
        # Remove common unwanted patterns
        unwanted_patterns = [
            'Skip to main content',
            'JavaScript is disabled',
            'Enable JavaScript',
            'Cookie Policy',
            'Privacy Policy'
        ]
        
        for pattern in unwanted_patterns:
            text = text.replace(pattern, '')
            
        return text.strip()
        
    def scrape_page(self, url: str, website_config: Dict, depth: int = 0) -> None:
        """Scrape a single page"""
        if url in self.visited_urls or depth >= self.config.MAX_DEPTH:
            return
            
        self.visited_urls.add(url)
        logger.info(f"Scraping {url} (depth: {depth})")
        
        # Determine if we need selenium for this site
        use_selenium = 'irdai.gov.in' in url or depth > 0
        
        soup = self.get_page_content(url, use_selenium)
        if not soup:
            return
            
        # Extract content
        title = soup.find('title')
        title_text = title.get_text().strip() if title else "No title"
        
        # Extract main content
        content_selectors = [
            'main', 'article', '.content', '#content', 
            '.main-content', '.page-content', 'div.container',
            '.document-list', '.regulation-content', '.circular-content'
        ]
        
        content_text = ""
        for selector in content_selectors:
            content_div = soup.select_one(selector)
            if content_div:
                content_text = content_div.get_text()
                break
                
        if not content_text:
            content_text = soup.get_text()
            
        content_text = self.clean_text(content_text)
        
        # Extract document links with enhanced logic
        doc_links = self.extract_document_links(soup, url)
        
        # For IRDAI pages, also extract regulation/circular specific links
        if 'irdai.gov.in' in url:
            # Look for regulation tables
            for table in soup.find_all('table'):
                for row in table.find_all('tr'):
                    cells = row.find_all(['td', 'th'])
                    if len(cells) >= 2:
                        # Check if this looks like a document row
                        for cell in cells:
                            link = cell.find('a', href=True)
                            if link:
                                href = link.get('href')
                                if href:
                                    if 'document-detail' in href or any(ext in href.lower() for ext in ['.pdf', '.doc']):
                                        doc_links.append(urljoin(url, href))
            
            # Look for download buttons or links
            for element in soup.find_all(['a', 'button'], text=re.compile(r'(download|view|pdf)', re.I)):
                if element.get('href'):
                    doc_links.append(urljoin(url, element.get('href')))
        
        # Remove duplicates
        doc_links = list(set(doc_links))
        
        # Create scraped content object
        scraped_content = ScrapedContent(
            url=url,
            title=title_text,
            content=content_text,
            source_type=website_config['type'],
            document_links=doc_links,
            metadata={
                'scraped_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                'depth': depth,
                'source_website': website_config['base_url'],
                'content_length': len(content_text),
                'document_count': len(doc_links)
            }
        )
        
        self.scraped_data.append(scraped_content)
        logger.info(f"Found {len(doc_links)} document links on {url}")
        
        # Get links for next level
        if depth < self.config.MAX_DEPTH - 1:
            links = self.extract_links(soup, website_config['base_url'], 
                                     website_config['priority_paths'])
            
            # Scrape next level (limit to prevent infinite recursion)
            for link in links[:10]:  # Limit to 10 links per page
                time.sleep(self.config.SCRAPING_DELAY)
                self.scrape_page(link, website_config, depth + 1)
                
    def scrape_all_websites(self) -> List[ScrapedContent]:
        """Scrape all configured websites"""
        logger.info("Starting web scraping process")
        
        for website_name, website_config in self.config.WEBSITES.items():
            logger.info(f"Scraping {website_name}: {website_config['base_url']}")
            
            # Start with base URL
            self.scrape_page(website_config['base_url'], website_config)
            
            # Scrape priority paths
            for path in website_config['priority_paths']:
                full_url = urljoin(website_config['base_url'], path)
                time.sleep(self.config.SCRAPING_DELAY)
                self.scrape_page(full_url, website_config)
                
        self.close_driver()
        logger.info(f"Scraping completed. Total pages scraped: {len(self.scraped_data)}")
        
        return self.scraped_data
        
    def save_scraped_data(self, output_file: str = "data/scraped/scraped_data.json"):
        """Save scraped data to JSON file"""
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        
        # Convert to JSON-serializable format
        data_dict = []
        for content in self.scraped_data:
            data_dict.append({
                'url': content.url,
                'title': content.title,
                'content': content.content,
                'source_type': content.source_type,
                'document_links': content.document_links,
                'metadata': content.metadata
            })
            
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(data_dict, f, indent=2, ensure_ascii=False)
            
        logger.info(f"Scraped data saved to {output_file}")
        
    def load_scraped_data(self, input_file: str = "data/scraped/scraped_data.json") -> List[ScrapedContent]:
        """Load scraped data from JSON file"""
        if not os.path.exists(input_file):
            logger.warning(f"No scraped data found at {input_file}")
            return []
            
        with open(input_file, 'r', encoding='utf-8') as f:
            data_dict = json.load(f)
            
        self.scraped_data = []
        for item in data_dict:
            content = ScrapedContent(
                url=item['url'],
                title=item['title'],
                content=item['content'],
                source_type=item['source_type'],
                document_links=item['document_links'],
                metadata=item['metadata']
            )
            self.scraped_data.append(content)
            
        logger.info(f"Loaded {len(self.scraped_data)} scraped items from {input_file}")
        return self.scraped_data